/* cobra2.c: CoBra 2 Turbo Spectrum (https://cobrasov.org) specific machine profile
   Copyright (c) 2023 Stefan V. Pantazi
   
   Copyright (c) 1999-2011 Philip Kendall
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   Stefan V. Pantazi (svpantazi@gmail.com)
   Apr 22, 2023

*/

#include <config.h>

#include <stdio.h>

#include <libspectrum.h>

#include "machine.h"
#include "machines.h"
#include "machines_periph.h"
#include "memory_pages.h"
#include "periph.h"
#include "settings.h"
#include "cobra2.h"
#include "spec48.h"

#define VRAM_PAGE 1
#define ROM_PAGE  2

static int cobra2_reset( void );

int cobra2_port_from_ula( libspectrum_word port )
{  /* No ULA, no contended ports */
  return 0;
}

int cobra2_init( fuse_machine_info *machine )
{
  machine->machine                    = LIBSPECTRUM_MACHINE_COBRA2;
  machine->id                         = "cobra2";
  machine->reset                      = cobra2_reset;
  machine->timex                      = 0;
  machine->ram.port_from_ula          = cobra2_port_from_ula;
  machine->ram.contend_delay	        = spectrum_contend_delay_none;
  machine->ram.contend_delay_no_mreq  = spectrum_contend_delay_none; 
  machine->ram.valid_pages	          = 4; 
  machine->unattached_port            = spectrum_unattached_port_none;
  machine->shutdown                   = NULL;
  machine->memory_map                 = cobra2_memory_map;

  return 0;
}

static int cobra2_reset( void )
{
  int error;
  error = machine_load_rom(ROM_PAGE, settings_current.rom_cobra2, settings_default.rom_cobra2, 0x4000 );
  if( error ) return error;

  periph_clear();
  machines_periph_48();

  /*removing spectrum ULA adding full decoding*/
  periph_set_present( PERIPH_TYPE_ULA, PERIPH_PRESENT_NEVER );
  periph_set_present( PERIPH_TYPE_ULA_FULL_DECODE, PERIPH_PRESENT_ALWAYS );  
  periph_set_present( PERIPH_TYPE_COBRA2_MEMORY, PERIPH_PRESENT_ALWAYS );
  periph_update();

  
/*in TS, memory maps depends on the combination of states CE and SM flip-flops
  screen RAM can be located at c000 or 4000; it starts at c000
  also per TS specification, the flops SM (bit 6) and CE (bit 5) flops are 0 and 1 after machine (HARD) reset  */

  machine_current->ram.last_byte2 &= !0x40;
  machine_current->ram.last_byte2 |= 0x20;
  
  spec48_common_display_setup();

  cobra2_common_reset();

  return 0;
}

/* Per the TS specification [page 11, section 2.7] an out instruction to an even
  address port (for ex. 0xfe) will store the output data byte in the F5 register.
  Bit 5 (Q5) of the stored byte b is an input into the CE flop and bit 6 (Q6) is 
  an input to the SM flop.*/
libspectrum_byte cobra2_memoryport_read( libspectrum_word port, libspectrum_byte *attached )
{
  *attached=1;
  if (!machine_current->ram.locked) 
  {
    if ((machine_current->ram.last_byte & 0x60) != (machine_current->ram.last_byte2 & 0x60)){
      machine_current->ram.last_byte2 = machine_current->ram.last_byte; 
      /*memory map has changed */
      machine_current->memory_map();              
    }  
  }
  return machine_current->ram.last_byte;  
}

void cobra2_memoryport_write( libspectrum_word port, libspectrum_byte b)
{
  machine_current->ram.last_byte=b;  
}

int cobra2_common_reset( void )
{    
  /*overriding the spec48 pages - for no memory contention*/
  memory_ram_set_16k_contention( 0, 0 );
  memory_ram_set_16k_contention( 1, 0 );
  memory_ram_set_16k_contention( 2, 0 );
  memory_ram_set_16k_contention( 3, 0 );

  /*hardware map EPROM mode: 2,3,0,1 */
  memory_map_16k( 0x0000, memory_map_rom, ROM_PAGE);
  memory_map_16k( 0x4000, memory_map_ram, 3);  
  memory_map_16k( 0x8000, memory_map_ram, 0);  
  memory_map_16k( 0xc000, memory_map_ram, VRAM_PAGE);
   
  
  machine_current->ram.locked = 0;
  machine_current->ram.special = 0;

  memory_current_screen = VRAM_PAGE;
  display_update_critical( 0, 0 );
  display_refresh_main_screen();        
  return 0;
}


/*Currently, there is an unsolved problem in TS boot whereby the top 1/3 of the image does not display properly.
From the TS specification, this paragraph may be relevant:
"Although it is desirable for 16-bit addresses to be aligned, Z80 fetches the address of the interrupt service routine in 2 cycles,
first the low byte at the address provided by the I register concatenated with the byte read during the interrupt, then it uses the
internal 16-bit adder to compute the address of the high byte. TS uses this undocumented feature and does not drive anything
during the interrupt and lets the pull-up resistors to provide the 0ffh value."*/

int cobra2_memory_map( void )
{
  uint8_t CE,SM;
  CE = !!(machine_current->ram.last_byte2 & 0x20);
  SM = !!(machine_current->ram.last_byte2 & 0x40);  
 
  if (CE && !SM){ /*EPROM mode - boot*/
      cobra2_common_reset();      
  }
  else
  {
    if (!SM){/*64k DRAM mode (good for CP/M?)*/
      /* UNTESTED - TODO /memory_map_16k(0x0000, memory_map_ram, ROM_PAGE);*/
      machine_current->ram.special = 1;

    }  else  {/*Spectrum mode*/
      memory_map_16k_read_write(0x0000, memory_map_ram, 0,1,0 );
      memory_map_16k(0x4000, memory_map_ram, 1 );  
      memory_map_16k(0x8000, memory_map_ram, ROM_PAGE );  
      memory_map_16k(0xc000, memory_map_ram, 3 );      
      machine_current->ram.locked=1;
    }
  }
  return 0;
}

