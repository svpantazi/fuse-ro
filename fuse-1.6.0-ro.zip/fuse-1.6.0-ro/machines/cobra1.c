/* cobra1.c: CoBra 1 64k (https://cobrasov.com) specific machine profile
   Copyright (c) 2023 Stefan V. Pantazi
   
   Copyright (c) 1999-2011 Philip Kendall
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   Stefan V. Pantazi (svpantazi@gmail.com)
   Apr 22, 2023

*/

#include <config.h>

#include <stdio.h>

#include <libspectrum.h>

#include "machine.h"
#include "machines.h"
#include "machines_periph.h"
#include "memory_pages.h"
#include "periph.h"
#include "settings.h"
#include "cobra1.h"
#include "spec48.h"
#include "z80/z80.h"

#define BOOT_ROM_PAGE   2
#define BASIC_ROM_PAGE  3
#define VRAM_PAGE       1

static int cobra1_reset( void );
static int cobra1_shutdown( void );
static int cobra1_config_switch(void);


int cobra1_port_from_ula( libspectrum_word port )
{
  /* No ULA, no contended ports */
  return 0;
}

int cobra1_init( fuse_machine_info *machine )
{
  machine->machine                    = LIBSPECTRUM_MACHINE_COBRA1;
  machine->id                         = "cobra1";
  machine->reset                      = cobra1_reset;
  
  /*Specific to this machine*/
  machine->r7bit_reset                = cobra1_config_switch;

  machine->timex                      = 0;
  machine->ram.port_from_ula          = cobra1_port_from_ula;
  machine->ram.contend_delay	        = spectrum_contend_delay_none;
  machine->ram.contend_delay_no_mreq  = spectrum_contend_delay_none;
  
  /*Specific as DRAM 0 and VRAM 2 are mapped in 8k pages*/
  machine->ram.valid_pages	          = 8; 
  machine->unattached_port            = spectrum_unattached_port_none;

  machine->shutdown                   = cobra1_shutdown;
  machine->memory_map                 = cobra1_memory_map;
  
  return 0;
}

static int cobra1_shutdown(void){
  return 0;
}

static int cobra1_reset( void )
{
  int error;

  error = machine_load_rom(BOOT_ROM_PAGE, settings_current.rom_cobra1_stdboot, settings_default.rom_cobra1_stdboot, 0x4000 );  
  if( error ) return error;
  error = machine_load_rom(BASIC_ROM_PAGE, settings_current.rom_48, settings_current.rom_48, 0x4000 );
  if( error ) return error;
  
  periph_clear();
  machines_periph_48();

  periph_set_present( PERIPH_TYPE_ULA, PERIPH_PRESENT_NEVER );
  periph_set_present( PERIPH_TYPE_ULA_FULL_DECODE, PERIPH_PRESENT_ALWAYS );  
  periph_set_present( PERIPH_TYPE_COBRA1_MEMORY, PERIPH_PRESENT_ALWAYS );
  periph_update();

  /*in cobra1, memory maps depends on the combination of states CE and SM flip-flops
    screen RAM can be located at c000 or 4000; it starts at c000
    //vram at c000 in EPROM and 64k mode
    //vram at 4000 in spectrum mode
  */

  machine_current->ram.locked = 0;
  machine_current->ram.special = 0;

  /*per Cobra specification, the bit O6 is 1 for CP/M mode and 0 for Basic. 
  Bit O5 is not used currently but later in multiboot can be used to switch EPROM banks  */
  machine_current->ram.last_byte2=0;
  
  spec48_common_display_setup();

  cobra1_common_reset();

  return 0;
}


int cobra1_common_reset( void )
{    
  /*overriding the spec48 pages - for no memory contention*/
  memory_ram_set_16k_contention( 0, 0 );
  memory_ram_set_16k_contention( 1, 0 );
  memory_ram_set_16k_contention( 2, 0 );
  memory_ram_set_16k_contention( 3, 0 );
   
  //4,5,6,7 0,3,2,1 is the correct 8k page sequence at boot
  memory_map_8k( 0x0000, memory_map_rom, 4); 
  memory_map_8k( 0x2000, memory_map_rom, 5);   
  memory_map_8k( 0x4000, memory_map_rom, 6);     
  memory_map_8k( 0x6000, memory_map_rom, 7);       
  
  memory_map_8k(0x8000, memory_map_ram, 0);
  memory_map_8k(0xa000, memory_map_ram, 3);  
  memory_map_8k(0xc000, memory_map_ram, 2);        
  memory_map_8k(0xe000, memory_map_ram, VRAM_PAGE);        
  
  machine_current->ram.special = 0;

  memory_current_screen = VRAM_PAGE;      
  
  display_update_critical( 0, 0 );
  display_refresh_main_screen();      

  return 0;
}

void cobra1_memoryport_write( libspectrum_word port, libspectrum_byte b)
{  
  machine_current->ram.last_byte=b;  
}

int cobra1_config_switch(void){
  /*R bit 7 CoBRA config switching trick*/
  machine_current->memory_map();          

  /*I could not find an easy way to make fuse complete the trick and reset the CPU, 
  so I cheat here*/
  z80_reset(0);
  return 0;
}

int cobra1_memory_map( void )
{  
  uint8_t O5,O6;
  O5 = !!(machine_current->ram.last_byte2 & 0x20);
  O6 = !!(machine_current->ram.last_byte2 & 0x40);  
  
  /* z80.r7==0x00 is EPROM mode, z80.r7==0x80 is memory map configuration mode */
  if (z80.r7==128){  
      if (O6){/*CP/M 64k mode*/
        /*UNTESTED, TODO
         memory_map_16k(0x0000, memory_map_ram, 2);
        memory_map_16k(0x4000, memory_map_ram, 3);

        memory_map_8k(0x8000, memory_map_ram, 0);        
        memory_map_8k(0xa000, memory_map_ram, 3);  

        memory_map_8k(0xc000, memory_map_ram, 2);        
        memory_map_8k(0xe000, memory_map_ram, VRAM_PAGE);        
        */                
        machine_current->ram.special = 1;
      }  else {/* Basic Spectrum 48k mode*/

        memory_map_8k_read_write(0x0000, memory_map_ram, 0,1,0);
        memory_map_8k_read_write(0x2000, memory_map_ram, 1,1,0);

        memory_map_8k(0x4000, memory_map_ram, 2);      
        memory_map_8k(0x6000, memory_map_ram, 3);      
    
        memory_map_8k(0x8000, memory_map_ram, 4);      
        memory_map_8k(0xa000, memory_map_ram, 5);      

        memory_map_8k(0xc000, memory_map_ram, 6);      
        memory_map_8k(0xe000, memory_map_ram, 7);      
    
        machine_current->ram.locked=1;
      }    
  }
  return 0;
}

