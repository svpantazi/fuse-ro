/* cobra1.c: CoBra 1 64k-80k (https://cobrasov.com) specific machine profile
   Copyright (c) 2023 Stefan V. Pantazi
   
   Copyright (c) 1999-2011 Philip Kendall
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   Stefan V. Pantazi (svpantazi@gmail.com)
   Apr-Aug 2023

*/

#include <config.h>

#include <stdio.h>

#include <libspectrum.h>

#include "machine.h"
#include "machines.h"
#include "machines_periph.h"
#include "memory_pages.h"
#include "periph.h"
#include "settings.h"
#include "cobra1.h"

#include "spec48.h"

#if 0
  #include "z80/z80.h"
  #include "machines/debug_ro.h"
#else
  #define dbg(x...)
  #define dbgp(x...)
#endif

#define RAM_ZERO_16k_PAGE   0
#define VRAM_16k_PAGE       1
#define BOOT_ROM_16k_PAGE   2
#define SYS_ROM_16k_PAGE    3

#define DRAM1_16k_PAGE      4

#define VRAM_8k_PAGE_1      (2*VRAM_16k_PAGE)
#define VRAM_8k_PAGE_2      (2*VRAM_16k_PAGE+1)
#define RAM_ZERO_8k_PAGE_1  (2*RAM_ZERO_16k_PAGE)
#define RAM_ZERO_8k_PAGE_2  (2*RAM_ZERO_16k_PAGE+1)

#define OPUS_ROM         0
#define BASIC_ROM        1
#define DEVIL_ROM        2
#define CPM_ROM          3

#define PO               machine_current->ram.last_byte
#define LO6              machine_current->ram.last_byte2

memory_page cobra_system_map_rom[COBRA_SYSTEM_ROM_PAGES*MEMORY_PAGES_IN_16K];

static int cobra1_reset( void );
static int cobra1_shutdown( void );

/*8255 IO from zxatasp.c*/
static const libspectrum_byte MC8255_PORT_C_LOW_IO  = 0x01;
static const libspectrum_byte MC8255_PORT_B_IO      = 0x02;
static const libspectrum_byte MC8255_PORT_C_HI_IO   = 0x08;
static const libspectrum_byte MC8255_PORT_A_IO      = 0x10;
static const libspectrum_byte MC8255_SETMODE        = 0x80;

static libspectrum_byte IO_8255_C_port_value;
static libspectrum_byte IO_8255_control_value;

static int cobra1_shutdown(void){
  return 0;
}

void
cobra_multiboot_rom_bank_source_init( void ){
  size_t i, j;
  for( i = 0; i < COBRA_SYSTEM_ROM_PAGES; i++ )
    for( j = 0; j < MEMORY_PAGES_IN_16K; j++ ) {
      memory_page *page = &cobra_system_map_rom[i * MEMORY_PAGES_IN_16K + j];
      page->writable = 0;
      page->contended = 0;
      page->source = memory_source_rom;
    }
}

static int
cobra_frame_interrupt( void )
{
  /*allow interrupts only in boot mode */
  return machine_current->ram.special ? 1 : 0;
}

int cobra1_init( fuse_machine_info *machine )
{
  machine->machine                    = LIBSPECTRUM_MACHINE_COBRA1;
  machine->id                         = "cobra1";
  machine->reset                      = cobra1_reset;
  
  machine->timex                      = 0;
  machine->ram.port_from_ula          = spec48_port_from_ula;
  machine->ram.contend_delay	        = spectrum_contend_delay_65432100;
  machine->ram.contend_delay_no_mreq  = spectrum_contend_delay_65432100;
  
  /*Specific as DRAM 0 and VRAM 2 are mapped in 8k pages*/
  machine->ram.valid_pages	          = 8; 
  machine->unattached_port            = spectrum_unattached_port_none;

  machine->shutdown                   = cobra1_shutdown;
  machine->memory_map                 = cobra1_memory_map;
  
  /*Specific to this machine*/
  machine->rfsh_check_page            = rfsh_check_page_handler;

  machine->frame_interrupt            = cobra_frame_interrupt;

  cobra_multiboot_rom_bank_source_init();

  return 0;
}

static void
io_8255_port_c_reset( void ){/*from ztatasp.c*/  
  IO_8255_C_port_value = (IO_8255_control_value & MC8255_PORT_C_LOW_IO) ? 0x0f : 0x00;
  IO_8255_C_port_value |= (IO_8255_control_value & MC8255_PORT_C_HI_IO) ? 0xf0 : 0x00;
}
 
static int cobra1_reset( void ){
  int error;
  dbg("\n\n-------------------------- CoBRA RESET");

  error = machine_load_rom(BOOT_ROM_16k_PAGE, settings_current.rom_cobra1_stdboot, settings_default.rom_cobra1_stdboot, 0x4000 );  
  if( error ) return error;

  /*basic=1 opus=0 devil=2 cpm=3 ROM by default*/
  error = machine_load_rom_bank(cobra_system_map_rom,OPUS_ROM, settings_current.rom_cobra1_sys_0, settings_default.rom_cobra1_sys_0, 0x4000 );  
  if( error ) return error;  
  error = machine_load_rom_bank(cobra_system_map_rom,BASIC_ROM, settings_current.rom_cobra1_sys_1, settings_default.rom_cobra1_sys_1, 0x4000 );   
  if( error ) return error;  
  error = machine_load_rom_bank(cobra_system_map_rom,DEVIL_ROM, settings_current.rom_cobra1_sys_2, settings_default.rom_cobra1_sys_2, 0x4000 );   
  if( error ) return error;  
  error = machine_load_rom_bank(cobra_system_map_rom,CPM_ROM, settings_current.rom_cobra1_sys_3, settings_default.rom_cobra1_sys_3, 0x4000 );        
  if( error ) return error;  

  periph_clear();
  machines_periph_48();

  periph_set_present( PERIPH_TYPE_ULA, PERIPH_PRESENT_NEVER );
  
  periph_set_present( PERIPH_TYPE_ULA_FULL_DECODE, PERIPH_PRESENT_ALWAYS );  
  periph_set_present( PERIPH_TYPE_COBRA1_MEMORY, PERIPH_PRESENT_ALWAYS );
  periph_set_present( PERIPH_TYPE_COBRA_FDC, PERIPH_PRESENT_OPTIONAL );

  /*prevent if1 fdc to be attached, cobra has its own fd*/
  periph_set_present( PERIPH_TYPE_INTERFACE1, PERIPH_PRESENT_NEVER );
  periph_set_present( PERIPH_TYPE_INTERFACE1_FDC, PERIPH_PRESENT_NEVER );

  /*8255 from ztatasp.c*/  
  IO_8255_C_port_value=0;
  IO_8255_control_value = MC8255_SETMODE | MC8255_PORT_A_IO | MC8255_PORT_B_IO | MC8255_PORT_C_HI_IO | MC8255_PORT_C_LOW_IO;

  io_8255_port_c_reset();    

  /*in Cobra computers, memory maps depend on the combination of states of some flip-flops
    screen RAM can be located at 0xc000 or 0x4000
    tipically, vram at c000 in boot and 64k mode and vram at 0x4000 in spectrum mode

    QUOTE from spec: "In order to solve this problem created by the dual nature of the computer, a memory configuration and selection circuit was created that
    satisfies the conditions imposed by these three configurations. This circuit is made of two D-type flip-flops (U36), a BCD-to-decimal decoder (U56) and gates,
    being presented in the block diagram in Fig.2. The two flip-flops (U36) are forced to “1” at power-up, by a circuit made of C15, D02, R09, D03.
  */
  PO=1;
  LO6=1;
  
  machine_current->ram.locked = 0;  
  machine_current->ram.special = 0;
  machine_current->ram.current_rom  = OPUS_ROM;

  periph_update();
  cobra1_common_reset();
  spec48_common_display_setup();

  return 0;
}

int cobra1_common_reset( void )
{    
  /*overriding the spec48 pages - for no memory contention*/
  memory_ram_set_16k_contention( 0, 0 );
  memory_ram_set_16k_contention( 1, 0 );
  memory_ram_set_16k_contention( 2, 0 );
  memory_ram_set_16k_contention( 3, 0 );
  memory_ram_set_16k_contention( 4, 0 );
   
  memory_current_screen = VRAM_16k_PAGE;
  display_update_critical( 0, 0 );
  display_refresh_main_screen();      

  return 0;
}

libspectrum_byte 
cobra1_8255_ctrl_port_read(libspectrum_word port, libspectrum_byte *attached){  
  *attached =1;
  dbg("READ from PORT=%d, val=%d", port,IO_8255_control_value);    
  return IO_8255_control_value;
}

void
cobra1_8255_ctrl_port_write( libspectrum_word port, libspectrum_byte b)
{  /*from ztatasp.c*/
  /* this is a write to port 0xdf to select a 16k system from system EPROM*/
  dbg("WRITE to 8255 control PORT 0xdf=%d, val=%d", port, b);
  if ((port & 0x00ff)==0x00df)
  {
    if (b & MC8255_SETMODE){
      dbg("    b7=1 SET MODE");
      if (b & 0x01) dbg("    b0=1 SET port C low IO");  
      if (b & 0x02) dbg("    b1=1 SET port B IO");      
      if (b & 0x08) dbg("    b3=1 SET port C high IO");      
      if (b & 0x10) dbg("    b4=1 SET port A IO");           
      
      IO_8255_control_value=b;    
      io_8255_port_c_reset();
    }
    else{
      /* from ztatasp.c - 8255 emulation*/
      /* Set or reset a bit of port C */
      dbg("    b7=1 SET MODE");
      libspectrum_byte bit = (b >> 1) & 7;
      libspectrum_byte newC = IO_8255_C_port_value;
        
      if( b & 1 ) {
        newC |=  ( 1 << bit );
      } else {
        newC &= ~( 1 << bit );
      }      
      cobra1_8255_port_C_write( 0x00fe, newC );      
    }
  }
}


libspectrum_byte 
cobra1_8255_port_C_read(libspectrum_word port, libspectrum_byte *attached){
  *attached =1;
  
  dbg("READ from PORT=%d, val=%d", port,IO_8255_C_port_value);    
  
  return IO_8255_C_port_value;
}

void 
cobra1_8255_port_C_write( libspectrum_word port, libspectrum_byte b){/* from ztatasp.c */
  libspectrum_byte oldC = IO_8255_C_port_value;
  libspectrum_byte newC;
  if ((port & 0x00ff)==0x00fe)
  {
    /* updating of port C writes depend on the 8255 control bits */
    newC = ( IO_8255_control_value & MC8255_PORT_C_LOW_IO ) ? ( oldC & 0x0f ) : ( b & 0x0f );           
    newC |= ( IO_8255_control_value & MC8255_PORT_C_HI_IO ) ? ( oldC & 0xf0 ) : ( b & 0xf0 ); 

    IO_8255_C_port_value=newC;    
    machine_current->memory_map();

    dbg("WRITTEN to PORT 0xfe=0x%02x, val=0x%02x",port,IO_8255_C_port_value);        
  }    
}

void rfsh_check_page_handler( libspectrum_byte R7 ){/*adapted from Alex Badea's 2012 implementation of the R register configuration*/
  dbg("R7=%d", R7 & 0x80 );
  PO=(R7 & 0x80) >> 7;
  /* on the falling edge of R7, latch current value of port FE bit 6 */
  if(PO==0)  {
    dbg("PO=%d, LO6=%d",PO, LO6); 
    LO6=(IO_8255_C_port_value & 0x40) >> 6;         
  }     
  machine_current->memory_map();  
}


void cobra1_64k_startup_memory_map(){
  dbg("64k");  
  if (PO==1) {
    dbg("* BOOT/Startup 32k ROM + 32k RAM memory map");            
    memory_map_16k( 0x0000, memory_map_rom, BOOT_ROM_16k_PAGE);   
    memory_map_16k( 0x4000, cobra_system_map_rom, machine_current->ram.current_rom);
  }
  else{//(LO6==1) 
    dbg("********************************************* CP/M 64k RAM memory map mode");  
    memory_map_16k(0x0000, memory_map_ram, BOOT_ROM_16k_PAGE);        
    memory_map_16k(0x4000, memory_map_ram, SYS_ROM_16k_PAGE);
  }
  /*in 64k, rest of 8k mapping is the same in boot as in CPM*/
  memory_map_8k(0x8000, memory_map_ram, RAM_ZERO_8k_PAGE_1);        
  memory_map_8k(0xa000, memory_map_ram, VRAM_8k_PAGE_2);  
  memory_map_8k(0xc000, memory_map_ram, VRAM_8k_PAGE_1);        
  memory_map_8k(0xe000, memory_map_ram, RAM_ZERO_8k_PAGE_2);
}


void cobra1_80k_startup_memory_map( int O5, int O6 )
/*see http://cobrasov.com/CoBra%20Project/index.html harta memoriei - 80kb DRAM.pdf */
{      
  dbg(" ********************************************* 80k memory map PO=%d, LO6=%d, O6=%d, O5=%d",PO, LO6, O6, O5);    
  if (PO==1) {
    dbg("* 80k BOOT/Startup 32k ROM + 48k RAM memory map");            
    memory_map_16k(0x0000, memory_map_rom, BOOT_ROM_16k_PAGE);/*boot ROM*/
    memory_map_16k(0x4000, cobra_system_map_rom, machine_current->ram.current_rom);/*SYS ROM*/
    memory_map_16k(0x8000,memory_map_ram,RAM_ZERO_16k_PAGE);  /*DRAM#0*/
    if (O6) memory_map_16k(0xc000,memory_map_ram,VRAM_16k_PAGE);  /*VRAM or DRAM#1*/
    else memory_map_16k(0xc000,memory_map_ram,DRAM1_16k_PAGE);
  }
  else {//(LO6==1) 
    dbg("********************************************* CP/M 80k RAM memory map mode");      
    /*0,1,2,3 mapping CPM 80k - also needs interrupts*/
    memory_map_16k(0x0000,memory_map_ram,RAM_ZERO_16k_PAGE);/* DRAM#0  R/W    */
    if (O6)
      memory_map_16k_read_write(0x4000,memory_map_ram,VRAM_16k_PAGE,1,1); /* VRAM  */
    else
      memory_map_16k_read_write(0x4000,memory_map_ram,DRAM1_16k_PAGE,1,1);/*DRAM#1 */

    memory_map_16k(0x8000,memory_map_ram,BOOT_ROM_16k_PAGE);/*DRAM#2*/
    memory_map_16k(0xc000,memory_map_ram,SYS_ROM_16k_PAGE); /*DRAM#3*/
  }               
}

int cobra1_memory_map( void ){        
  uint8_t TO, SO, O5, O6, rom_idx; 

  if (machine_current->ram.locked) return 0;

  O5 = (IO_8255_C_port_value & 0x20) >> 5;  
  O6 = (IO_8255_C_port_value & 0x40) >> 6;  

  /*reusint output bits, TO is tape out, SO is serial out */
  TO = (IO_8255_C_port_value & 0x08) >> 3;  /* controls A15 of System EPROM */
  SO = (IO_8255_C_port_value & 0x80) >> 7;  /* controls A14 of System EPROM */
  rom_idx=((TO << 1)+SO);      
  machine_current->ram.current_rom=rom_idx;

  if ((PO==1) || (LO6==1)) {
    dbg("O5=%d, O6=%d, TO=%d, SO=%d, current ROM idx=%d",O5, O6, TO,SO, rom_idx);               
    /*Done: choose on 64k vs 80k from FUSE configuration option*/
    if (settings_current.cobra1_64k)
      cobra1_64k_startup_memory_map();
    else
      cobra1_80k_startup_memory_map(O5, O6);    
  }
  else /* PO==0 && LO6==0 */
  {
    /* Basic Spectrum 48k mode*/
      machine_current->ram.locked=1;
      dbg("* Basic Spectrum 16k (R/O RAM) + 48k RAM memory map mode");      
      /* first 16k RAM are made read only */
      memory_map_16k_read_write(0x0000,memory_map_ram,RAM_ZERO_16k_PAGE,1,0); /*DRAM#0 -> R/O*/
      memory_map_16k(0x4000,memory_map_ram,VRAM_16k_PAGE);                        
      memory_map_16k(0x8000,memory_map_ram,BOOT_ROM_16k_PAGE);
      memory_map_16k(0xc000,memory_map_ram,SYS_ROM_16k_PAGE);            
  }

  return 0;
}




