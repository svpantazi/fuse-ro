

#ifndef __DEBUG__
#define DEBUG
    /*https://www.cs.colostate.edu/~fsieker/misc/debug/DEBUG.html*/
    #ifdef DEBUG
        #define dbg(fmt, args...) fprintf(stderr, "%s:%d: z80PC:0x%04x | " fmt "\n", __func__, __LINE__,z80.pc.w, ## args)
    #else
        #define dbg(fmt, ...) ((void)0)
    #endif
#endif 

// #if 0
// #define dbg(fmt, args...) fprintf(stderr, "%s:%d: " fmt "\n", __func__, __LINE__, ## args)
// #define dbgp(x...) dbg(x)
// #else
// #define dbg(x...)
// #define dbgp(x...)
// #endif
