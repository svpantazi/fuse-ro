/* cobra2.c: CoBra 2 Turbo Spectrum (https://cobrasov.org) specific machine profile
   Copyright (c) 2023 Stefan V. Pantazi
   
   Copyright (c) 1999-2011 Philip Kendall
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   Stefan V. Pantazi (svpantazi@gmail.com)
   Apr-Aug, 2023

*/

#include <config.h>

#include <stdio.h>

#include <libspectrum.h>

#include "machine.h"
#include "machines.h"
#include "machines_periph.h"
#include "memory_pages.h"
#include "periph.h"
#include "settings.h"
#include "cobra1.h"
#include "cobra2.h"
#include "spec48.h"

#if 1
  #include "z80/z80.h"
  #include "machines/debug_ro.h"
#else
  #define dbg(x...)
  #define dbgp(x...)
#endif


#define RAM_PAGE_ZERO   0
#define VRAM_PAGE       1
#define RAM_PAGE_TWO    2
#define RAM_PAGE_THREE  3

/* the memory map config bits Q3 and Q7, on port 0xfe */
#define ROM_IDX_BITS 0x88

/* the memory map config bits  nCE, SM on port 0xfe */
#define MEM_MAP_BITS 0xE8

#define CURR_0xFE_VAL machine_current->ram.last_byte
//#define LAST_0xFE_VAL machine_current->ram.last_byte2

static int cobra2_reset( void );

int cobra2_port_from_ula( libspectrum_word port )
{  /* No ULA, no contended ports */
  return 0;
}

int cobra2_init( fuse_machine_info *machine )
{
  machine->machine                    = LIBSPECTRUM_MACHINE_COBRA2;
  machine->id                         = "cobra2";
  machine->reset                      = cobra2_reset;
  machine->timex                      = 0;
  machine->ram.port_from_ula          = cobra2_port_from_ula;//spec48_port_from_ula;//  /* All even ports supplied by ULA */ 
  machine->ram.contend_delay	        = spectrum_contend_delay_none;
  machine->ram.contend_delay_no_mreq  = spectrum_contend_delay_none; 
  
  machine->ram.valid_pages	          = 4; 
  
  machine->unattached_port            = spectrum_unattached_port_none;/* SP careful!!!! spectrum_unattached_port;*/
  
  machine->shutdown                   = NULL;
  machine->memory_map                 = cobra2_memory_map;

  cobra_multiboot_rom_bank_source_init();

  return 0;
}

static int cobra2_reset( void )
{
  int error;  
  /* multiboot ROM bank load   boot + basic=0, dev Basic=1, opus=2, ITCI Basic=3*/
  error = machine_load_rom_bank(cobra_system_map_rom,0, settings_current.rom_cobra2_TS4OS_0, settings_default.rom_cobra2_TS4OS_0, 0x4000 );   //Sinclair Basic
  if( error ) return error;  
  error = machine_load_rom_bank(cobra_system_map_rom,1, settings_current.rom_cobra2_TS4OS_1, settings_default.rom_cobra2_TS4OS_1, 0x4000 );   //Devil Basic
  if( error ) return error;  
  error = machine_load_rom_bank(cobra_system_map_rom,2, settings_current.rom_cobra2_TS4OS_2, settings_default.rom_cobra2_TS4OS_2, 0x4000 );   //Opus
  if( error ) return error;  
  error = machine_load_rom_bank(cobra_system_map_rom,3, settings_current.rom_cobra2_TS4OS_3, settings_default.rom_cobra2_TS4OS_3, 0x4000 );   //ITCI Basic

  if( error ) return error;  

  periph_clear();
  machines_periph_48();
  

  /*removing spectrum ULA adding full decoding*/
  periph_set_present( PERIPH_TYPE_ULA, PERIPH_PRESENT_NEVER );
  /* must have the full decode or disk won't work*/
  periph_set_present( PERIPH_TYPE_ULA_FULL_DECODE, PERIPH_PRESENT_ALWAYS );  
  /* cobra2 memory for port 0xfe configuration bits*/
  periph_set_present( PERIPH_TYPE_COBRA2_MEMORY, PERIPH_PRESENT_ALWAYS );

  periph_set_present( PERIPH_TYPE_COBRA_FDC, PERIPH_PRESENT_OPTIONAL );
  periph_set_present( PERIPH_TYPE_SIMPLECF, PERIPH_PRESENT_OPTIONAL );

  //SP testing AY on TS
  periph_set_present(PERIPH_TYPE_AY_TIMEX_WITH_JOYSTICK, PERIPH_PRESENT_ALWAYS );
  //periph_set_present(PERIPH_TYPE_AY_FULL_DECODE, PERIPH_PRESENT_ALWAYS );

  /* prevent if1 and if1 fdc from being attached */
  periph_set_present( PERIPH_TYPE_INTERFACE1, PERIPH_PRESENT_NEVER );
  periph_set_present( PERIPH_TYPE_INTERFACE1_FDC, PERIPH_PRESENT_OPTIONAL );



  periph_update();
/*in Cobra 2 TS, memory maps depends on the combination of states CE and SM flip-flops
  screen RAM can be located at 0xc000 or 0x4000; at boot it starts at 0xc000;
  also per TS specification, the nCE (bit Q5 of F3) and SM (bit Q6 of F3) flops are 1 and 0 respectively after machine (HARD) reset  */
  
  /* reset all memory map bits nCE, SM, Q3 and Q7 */
  //LAST_0xFE_VAL =0xff & !(MEM_MAP_BITS+ROM_IDX_BITS);
  //CURR_0xFE_VAL=LAST_0xFE_VAL;
  CURR_0xFE_VAL=0xff & !(MEM_MAP_BITS+ROM_IDX_BITS);
 
  machine_current->ram.locked = 0;  
  machine_current->ram.special = 0; /* this messes with interrupt control in older code */

  
  cobra2_common_reset();
  spec48_common_display_setup();

  return 0;
}

int cobra2_common_reset( void )
{    
  /*overriding the spec48 pages - for no memory contention*/
  memory_ram_set_16k_contention( 0, 0 );
  memory_ram_set_16k_contention( 1, 0 );
  memory_ram_set_16k_contention( 2, 0 );
  memory_ram_set_16k_contention( 3, 0 );

 
  memory_current_screen = VRAM_PAGE;
  display_update_critical( 0, 0 );
  display_refresh_main_screen();        
  return 0;
}

libspectrum_byte cobra2_configport_read( libspectrum_word port, libspectrum_byte *attached )
{  
  *attached=0xff;
  //how to emulate pullups on data bus - the default read on port 0xfe should be 0xff
  dbg("READ from CONFIG PORT=%d, val=%d", port & 0xff,CURR_0xFE_VAL);
  //if ((CURR_0xFE_VAL & MEM_MAP_BITS) != (LAST_0xFE_VAL & MEM_MAP_BITS)){
      //LAST_0xFE_VAL = CURR_0xFE_VAL; 
      /*memory map has changed */          
      machine_current->memory_map();              
    //}  
  return 0xff;
}


/* Per the TS specification [page 11, section 2.7] an out instruction to an even
  address port (for ex. 0xfe) will store the output data byte in the F5 register.
  Bit 5 (Q5 of F3) of the stored byte b is an input into the CE flop and bit 6 (Q6 of F3) is 
  an input to the SM flop.*/
libspectrum_byte cobra2_memoryport_read( libspectrum_word port, libspectrum_byte *attached )
{  
  *attached=0xff;
  //how to emulate pullups on data bus - the default read on port 0xfe should be 0xff
  //dbg("READ from PORT=%d, val=%d", port & 0xff,CURR_0xFE_VAL);                       
  // if (!machine_current->ram.locked)
  // {               
  //   if ((CURR_0xFE_VAL & MEM_MAP_BITS) != (LAST_0xFE_VAL & MEM_MAP_BITS)){
  //     LAST_0xFE_VAL = CURR_0xFE_VAL; 
  //     /*memory map has changed */          
  //     machine_current->memory_map();              
  //   }  
  // }     
  return CURR_0xFE_VAL;  
}

void cobra2_memoryport_write( libspectrum_word port, libspectrum_byte b)
{  
  CURR_0xFE_VAL=b;  
  //dbg("WROTE to PORT=%d, val=%d", port & 0xff,CURR_0xFE_VAL);       
}

/*The previous problem with TS boot whereby the top 1/3 of the image did not display properly was solved by
allowing the configuration switching to transition through the 64k DRAM mode from Boot to Spectrum mode. */
int cobra2_memory_map( void )
{
  uint8_t nCE,SM, rom_idx, Q7, Q3; 

  nCE = (CURR_0xFE_VAL & 0x20) >> 5;
   SM = (CURR_0xFE_VAL & 0x40) >> 6;  

  /* Q3=TO is tape out, Q7=SO is serial out/or unused in Cobra computers; 
    these output bits can be repurposed for EPROM selection at boot;
    A14 is connected to Q7 in F5 and A15 to Q3 in F5 for ROM selection */
  Q3 = (CURR_0xFE_VAL & 0x08) >> 3;  /* to A15 of System EPROM  */
  Q7 = (CURR_0xFE_VAL & 0x80) >> 7;  /* to A14 of System EPROM  */
  rom_idx=((Q3 << 1)+Q7);      

  if (nCE==0 && SM==0 ){ /*EPROM mode - boot*/
      dbg( "TS in EPROM-boot mode");            
      memory_map_16k( 0x0000, cobra_system_map_rom, rom_idx);     /* DRAM#2 - replaced by ROM */
      memory_map_16k( 0x4000, memory_map_ram, RAM_PAGE_THREE);    /* DRAM#3 */
      memory_map_16k( 0x8000, memory_map_ram, RAM_PAGE_ZERO);     /* DRAM#0 */
      memory_map_16k( 0xc000, memory_map_ram, VRAM_PAGE);         /* DRAM#1 */
  }
  else 
  {        
    if (nCE==1 && SM==1) {/*Spectrum mode*/
      dbg( "TS in Spectrum mode");      
      memory_map_16k_read_write(0x0000, memory_map_ram, RAM_PAGE_ZERO, 1, 0); /* DRAM#0 - page 0 is made Read Only!*/
      memory_map_16k(           0x4000, memory_map_ram, VRAM_PAGE);           /* DRAM#1*/
      memory_map_16k(           0x8000, memory_map_ram, RAM_PAGE_TWO);        /* DRAM#2*/
      memory_map_16k(           0xc000, memory_map_ram, RAM_PAGE_THREE);      /* DRAM#3*/

      /* lock the config so it cannot change until reset */
      //machine_current->ram.locked=1;
    }    
    else if (nCE==1 && SM==0) {/*64k DRAM mode (good for CP/M?)*/      
      dbg( "TS in 64k DRAM mode");
      /* remap 16k of RAM instead of ROM in page 2 */
      memory_map_16k_read_write(0x0000, memory_map_ram, RAM_PAGE_TWO, 1, 1);      
      /*NOTE: I cannot lock this configuration as the CPM mode is the transitory mode between EPROM and Spectrum 
      This configuration is also seems to be able to accomodate CP/M */

      //SP testing with keeping the 64k config locked
      //ONLY TESTING this is NOT real!
      #if LOCK_MEM_MAP
      machine_current->ram.locked=1;  
      #endif
    }
  }
  return 0;
}

