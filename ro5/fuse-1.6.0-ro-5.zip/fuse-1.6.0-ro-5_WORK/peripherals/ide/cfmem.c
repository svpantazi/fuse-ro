/* cfmem.c: R. Koning SuperSpec specific CF routines
    adapted by S.V. Pantazi from 
    Simple 8-bit IDE interface routines
   Copyright (c) 2003-2017 Garry Lancaster, Philip Kendall, Fredrick Meunier
   Copyright (c) 2015 Stuart Brady
   Copyright (c) 2016 Sergio Baldoví

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   E-mail: Philip Kendall <philip-fuse@shadowmagic.org.uk>

*/

#include <config.h>

#include <libspectrum.h>

#include "ide.h"
#include "infrastructure/startup_manager.h"
#include "module.h"
#include "periph.h"
#include "settings.h"
#include "cfmem.h"
#include "ui/ui.h"

//SP debug
#if 0
  #include "z80/z80.h"
  #include "machines/debug_ro.h"
#else
  #define dbg(x...)
  #define dbgp(x...)
#endif

/* Private function prototypes */

static libspectrum_byte cfmem_read( libspectrum_word port, libspectrum_byte *attached );
static void cfmem_write( libspectrum_word port, libspectrum_byte data );

/* Data */

static const periph_port_t cfmem_ports[] = {
  { 0x007f, 0x7f, cfmem_read, cfmem_write }, 
  { 0, 0, NULL, NULL }
};

static const periph_t cfmem_periph = {
  /* .option = */ &settings_current.cfmem_active,
  /* .ports = */ cfmem_ports,
  /* .hard_reset = */ 1,
  /* .activate = */ NULL,
};

static libspectrum_ide_channel *cfmem_idechn;

static void cfmem_snapshot_enabled( libspectrum_snap *snap );
static void cfmem_to_snapshot( libspectrum_snap *snap );

static module_info_t cfmem_module_info = {
  /* .reset = */ cfmem_reset,
  /* .romcs = */ NULL,
  /* .snapshot_enabled = */ cfmem_snapshot_enabled,
  /* .snapshot_from = */ NULL,
  /* .snapshot_to = */ cfmem_to_snapshot,
};

/* Housekeeping functions */

static int
cfmem_init( void *context )
{
  int error;

  //cfmem_idechn = libspectrum_ide_alloc( LIBSPECTRUM_IDE_DATA8 );
  cfmem_idechn = libspectrum_ide_alloc( LIBSPECTRUM_IDE_DATA16 );

  error = ide_init( cfmem_idechn,
		    settings_current.cfmem_master_file,
		    UI_MENU_ITEM_MEDIA_IDE_CFMEM_EJECT,
        NULL,
        UI_MENU_ITEM_MEDIA_IDE_CFMEM_EJECT);
		    //settings_current.cfmem_slave_file,
		    //UI_MENU_ITEM_MEDIA_IDE_CFMEM_EJECT );
  if( error ) return error;

  module_register( &cfmem_module_info );
  periph_register( PERIPH_TYPE_CFMEM, &cfmem_periph );

  return 0;
}

static void
cfmem_end( void )
{
  libspectrum_ide_free( cfmem_idechn );
}

void
cfmem_register_startup( void )
{
  startup_manager_module dependencies[] = {
    STARTUP_MANAGER_MODULE_DISPLAY,
    STARTUP_MANAGER_MODULE_SETUID
  };
  startup_manager_register( STARTUP_MANAGER_MODULE_CFMEM, dependencies,
                            ARRAY_SIZE( dependencies ), cfmem_init, NULL,
                            cfmem_end );
}

void
cfmem_reset( int hard_reset GCC_UNUSED )
{
  libspectrum_ide_reset( cfmem_idechn );
}

int
cfmem_insert( const char *filename, libspectrum_ide_unit unit )
{
  return ide_master_slave_insert(
    cfmem_idechn, unit, filename,
    &settings_current.cfmem_master_file,
    UI_MENU_ITEM_MEDIA_IDE_CFMEM_EJECT,
    NULL,
    UI_MENU_ITEM_MEDIA_IDE_CFMEM_EJECT);
    //&settings_current.cfmem_slave_file,
    //UI_MENU_ITEM_MEDIA_IDE_CFMEM_EJECT );
}

int
cfmem_commit( libspectrum_ide_unit unit )
{
  int error;

  error = libspectrum_ide_commit( cfmem_idechn, unit );

  return error;
}

int
cfmem_eject( libspectrum_ide_unit unit )
{
  return ide_master_slave_eject(
    cfmem_idechn, unit,
    &settings_current.cfmem_master_file,
    UI_MENU_ITEM_MEDIA_IDE_CFMEM_EJECT,
    NULL,
    UI_MENU_ITEM_MEDIA_IDE_CFMEM_EJECT);
    //&settings_current.cfmem_slave_file,
    //UI_MENU_ITEM_MEDIA_IDE_CFMEM_EJECT );
}

/* Port read/writes */


/* Data */
int cfmem_logcount2=0;

static libspectrum_byte
cfmem_read( libspectrum_word port, libspectrum_byte *attached )
{
  libspectrum_byte cfmem_read_value;
  libspectrum_ide_register idereg;  
  *attached = 0xff; /* TODO: check this */
//A15, A14, A8
  idereg = ( ( port >> 8 ) & 0x01 ) | ( ( port >> 13 ) & 0x06 );
  cfmem_read_value=libspectrum_ide_read( cfmem_idechn, idereg );  
  dbg("%d, READ from CF IDE PORT=0x%04x, IDEREG=%d, val=%d (0x%02x)", cfmem_logcount2, port,idereg,cfmem_read_value,cfmem_read_value);        
  cfmem_logcount2++;   
  //SP hack - faking the status value returned
  if (idereg==7 && cfmem_read_value==0x48) cfmem_read_value=0x58;
  return cfmem_read_value;
}  

static void
cfmem_write( libspectrum_word port, libspectrum_byte data )
{
  libspectrum_ide_register idereg;
  //A15, A14, A8
  idereg = ( ( port >> 8 ) & 0x01 ) | ( ( port >> 13 ) & 0x06 );  
  dbg("%d WRITE to CF IDE PORT=0x%04x,  IDEREG=%d, val=%d (0x%02x)", cfmem_logcount2,port,idereg, data,data);    
  cfmem_logcount2++;
  libspectrum_ide_write( cfmem_idechn, idereg, data ); 
}

static void
cfmem_snapshot_enabled( libspectrum_snap *snap )
{
  //SP need to change libspectrum for this one
  if( libspectrum_snap_simpleide_active( snap ) )
    settings_current.cfmem_active = 1;
}

static void
cfmem_to_snapshot( libspectrum_snap *snap )
{
  if( !settings_current.cfmem_active ) return;
//SP need to change libspectrum for this one
  libspectrum_snap_set_simpleide_active( snap, 1 );
}
