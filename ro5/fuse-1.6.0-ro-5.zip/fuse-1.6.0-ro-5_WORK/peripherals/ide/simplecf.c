/* simplecf.c: Simple 8-bit CF interface routines
   adapted by S.V. Pantazi from simpleide.h

   Copyright (c) 2003-2017 Garry Lancaster, Philip Kendall, Fredrick Meunier
   Copyright (c) 2015 Stuart Brady
   Copyright (c) 2016 Sergio Baldoví

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   E-mail: Philip Kendall <philip-fuse@shadowmagic.org.uk>

*/

#include <config.h>

#include <libspectrum.h>

#include "ide.h"
#include "infrastructure/startup_manager.h"
#include "module.h"
#include "periph.h"
#include "settings.h"
#include "simplecf.h"
#include "ui/ui.h"

//SP debug
#if 0
  #include "z80/z80.h"
  #include "machines/debug_ro.h"
#else
  #define dbg(x...)
  #define dbgp(x...)
#endif

/* Private function prototypes */

static libspectrum_byte simplecf_read( libspectrum_word port, libspectrum_byte *attached );
static void simplecf_write( libspectrum_word port, libspectrum_byte data );

/* Data */
int logcount=0;

static const periph_port_t simplecf_ports[] = {
  //SP hack, makes it clearer; May 9, 2024 changed range from 80h-87h to 10h-17h
  #define CF_PORT_BASE 0x80 //for some reason 0x10 does not work in this emulator
  //{ 0x0010, 0x0000, simplecf_read, simplecf_write },
  { 0x00ff, CF_PORT_BASE+0x0000, simplecf_read, simplecf_write },
  { 0x00ff, CF_PORT_BASE+0x0001, simplecf_read, simplecf_write },
  { 0x00ff, CF_PORT_BASE+0x0002, simplecf_read, simplecf_write },
  { 0x00ff, CF_PORT_BASE+0x0003, simplecf_read, simplecf_write },
  { 0x00ff, CF_PORT_BASE+0x0004, simplecf_read, simplecf_write },
  { 0x00ff, CF_PORT_BASE+0x0005, simplecf_read, simplecf_write },
  { 0x00ff, CF_PORT_BASE+0x0006, simplecf_read, simplecf_write },
  { 0x00ff, CF_PORT_BASE+0x0007, simplecf_read, simplecf_write },
  //{ 0x0078, CF_PORT_BASE, simplecf_read, simplecf_write },
  
  { 0, 0, NULL, NULL }
};

static const periph_t simplecf_periph = {
  /* .option = */ &settings_current.simplecf_active,
  /* .ports = */ simplecf_ports,
  /* .hard_reset = */ 1,
  /* .activate = */ NULL,
};

static libspectrum_ide_channel *simplecf_idechn;

static void simplecf_snapshot_enabled( libspectrum_snap *snap );
static void simplecf_to_snapshot( libspectrum_snap *snap );

static module_info_t simplecf_module_info = {

  /* .reset = */ simplecf_reset,
  /* .romcs = */ NULL,
  /* .snapshot_enabled = */ simplecf_snapshot_enabled,
  /* .snapshot_from = */ NULL,
  /* .snapshot_to = */ simplecf_to_snapshot,
};

/* Housekeeping functions */

static int
simplecf_init( void *context )
{
  int error;

//SP this - IDE DATA 16 when CF initialized properly for full capacity in 8 bit mode
    //SP hack FTW!!!!  - this is what made SimpleCF work
    //SP hack FTW!!!! - this is what made SimpleCF on port 80h-87h work; changed the data counter increment from 2 to 1
//SP - this hack has to do with CF card being accessed in half or full capacity; 
//if the hack is active, access is done in 8 bit mode, full capacity, no halved!
//#define SP_IDE_HACK


  //simplecf_idechn = libspectrum_ide_alloc( LIBSPECTRUM_IDE_DATA8 );
  simplecf_idechn = libspectrum_ide_alloc( LIBSPECTRUM_IDE_DATA16 );

  error = ide_init( simplecf_idechn,
		    settings_current.simplecf_master_file,
		    UI_MENU_ITEM_MEDIA_IDE_SIMPLECF_MASTER_EJECT,
		    settings_current.simplecf_slave_file,
		    UI_MENU_ITEM_MEDIA_IDE_SIMPLECF_SLAVE_EJECT );
  if( error ) return error;

  module_register( &simplecf_module_info );
  periph_register( PERIPH_TYPE_SIMPLECF, &simplecf_periph );

  return 0;
}

static void
simplecf_end( void )
{
  libspectrum_ide_free( simplecf_idechn );
}

void
simplecf_register_startup( void )
{
  startup_manager_module dependencies[] = {
    //SP hack 
    STARTUP_MANAGER_MODULE_DISPLAY,
    //STARTUP_MANAGER_MODULE_MEMORY,
    STARTUP_MANAGER_MODULE_SETUID
  };
  startup_manager_register( STARTUP_MANAGER_MODULE_SIMPLECF, dependencies,
                            ARRAY_SIZE( dependencies ), simplecf_init, NULL,
                            simplecf_end );
}

void
simplecf_reset( int hard_reset GCC_UNUSED )
{
  libspectrum_ide_reset( simplecf_idechn );
}

int
simplecf_insert( const char *filename, libspectrum_ide_unit unit )
{
  return ide_master_slave_insert(
    simplecf_idechn, unit, filename,
    &settings_current.simplecf_master_file,
    UI_MENU_ITEM_MEDIA_IDE_SIMPLECF_MASTER_EJECT,
    &settings_current.simpleide_slave_file,
    UI_MENU_ITEM_MEDIA_IDE_SIMPLECF_SLAVE_EJECT );
}

int
simplecf_commit( libspectrum_ide_unit unit )
{
  int error;

  error = libspectrum_ide_commit( simplecf_idechn, unit );

  return error;
}

int
simplecf_eject( libspectrum_ide_unit unit )
{
  return ide_master_slave_eject(
    simplecf_idechn, unit,
    &settings_current.simplecf_master_file,
    UI_MENU_ITEM_MEDIA_IDE_SIMPLECF_MASTER_EJECT,
    &settings_current.simplecf_slave_file,
    UI_MENU_ITEM_MEDIA_IDE_SIMPLECF_SLAVE_EJECT );
}

/* Port read/writes */
libspectrum_byte simplecf_read_value;

static libspectrum_byte
simplecf_read( libspectrum_word port, libspectrum_byte *attached )
{
  libspectrum_ide_register idereg;
  
  *attached = 0xff; /* TODO: check this */
  //SP hack - Pera P. original design that worked with A8, A12, A13 connected to A0,A1,A2  (11000100000000)
  //oldidereg = ( ( port >> 8 ) & 0x01 ) | ( ( port >> 11 ) & 0x06 );  
  idereg = port & 7;
  //idereg =  (port >> 8 ) & 7;

  simplecf_read_value=libspectrum_ide_read( simplecf_idechn, idereg ); 

  // if (idereg==0){}
  // else
  {

  dbg("%d, READ from CF IDE PORT=0x%04x, IDEREG=%d, val=%d (0x%02x)", logcount, port,idereg,simplecf_read_value,simplecf_read_value);      


  }

  logcount++;
  return simplecf_read_value; 
}  

static void
simplecf_write( libspectrum_word port, libspectrum_byte data )
{
  libspectrum_ide_register idereg;
  
    //SP hack
  //idereg = ( ( port >> 8 ) & 0x01 ) | ( ( port >> 11 ) & 0x06 );
  idereg = port & 7;
  
  dbg("%d WRITE to CF IDE PORT=0x%04x,  IDEREG=%d, val=%d (0x%02x)", logcount,port,idereg, data,data);  

  logcount++;

  libspectrum_ide_write( simplecf_idechn, idereg, data );   
}

static void
simplecf_snapshot_enabled( libspectrum_snap *snap )
{
  //SP need to change libspectrum for this one
  if( libspectrum_snap_simpleide_active( snap ) )
    settings_current.simplecf_active = 1;
}

static void
simplecf_to_snapshot( libspectrum_snap *snap )
{
  if( !settings_current.simplecf_active ) return;
//SP need to change libspectrum for this one
  libspectrum_snap_set_simpleide_active( snap, 1 );
}
