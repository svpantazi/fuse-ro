/* simpleide.c: Simple 8-bit IDE interface routines
   Copyright (c) 2003-2017 Garry Lancaster, Philip Kendall, Fredrick Meunier
   Copyright (c) 2015 Stuart Brady
   Copyright (c) 2016 Sergio Baldoví

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   E-mail: Philip Kendall <philip-fuse@shadowmagic.org.uk>

*/

#include <config.h>

#include <libspectrum.h>

#include "ide.h"
#include "infrastructure/startup_manager.h"
#include "module.h"
#include "periph.h"
#include "settings.h"
#include "simpleide.h"
#include "ui/ui.h"

//SP hack
#if 0
  #include "z80/z80.h"
  #include "machines/debug_ro.h"
#else
  #define dbg(x...)
  #define dbgp(x...)
#endif

#define  IDE_MODE 2 //0-original A8,A12,A13, 1-A2,A6,A7, 2-A3,A6,A7 (CoBra 1 compatible)


/* Private function prototypes */

static libspectrum_byte simpleide_read( libspectrum_word port, libspectrum_byte *attached );
static void simpleide_write( libspectrum_word port, libspectrum_byte data );

/* Data */

static const periph_port_t simpleide_ports[] = {
#if (IDE_MODE==0)
  { 0x0010, 0x0000, simpleide_read, simpleide_write }, //original in fuse works with sm8* +3e ROMS (A4-CS0, A8,A12,A13); A14=1
#else 
  #if (IDE_MODE==1)
  //Works with Octocom workbench HDF 16 bit
    {0x002b, 0x002b, simpleide_read, simpleide_write }, //testing   - works with pcf* +3e ROMS (A4-CS0, A2,A6,A7) 

  #else  //Mode 2 - Cobra 1 compatible - needs  hex bin patching of ports *b -> *7  
    //{0x0027, 0x0027, simpleide_read, simpleide_write }, //testing   - works with pcf* +3e ROMS (A4-CS0, A3,A6,A7)   
    { 0x0010, 0x0000, simpleide_read, simpleide_write },
  #endif
#endif
  { 0, 0, NULL, NULL }
};

static const periph_t simpleide_periph = {
  /* .option = */ &settings_current.simpleide_active,
  /* .ports = */ simpleide_ports,
  /* .hard_reset = */ 1,
  /* .activate = */ NULL,
};

static libspectrum_ide_channel *simpleide_idechn;

static void simpleide_snapshot_enabled( libspectrum_snap *snap );
static void simpleide_to_snapshot( libspectrum_snap *snap );

static module_info_t simpleide_module_info = {

  /* .reset = */ simpleide_reset,
  /* .romcs = */ NULL,
  /* .snapshot_enabled = */ simpleide_snapshot_enabled,
  /* .snapshot_from = */ NULL,
  /* .snapshot_to = */ simpleide_to_snapshot,

};

/* Housekeeping functions */

static int
simpleide_init( void *context )
{
  int error;

#if  (IDE_MODE==0)
  simpleide_idechn = libspectrum_ide_alloc( LIBSPECTRUM_IDE_DATA8 );
#else
  //this works Mode 1, A2,A6,A7 and Mode 2- A3, A6, A7 (Cobra)
  simpleide_idechn = libspectrum_ide_alloc( LIBSPECTRUM_IDE_DATA16 );
#endif  

  error = ide_init( simpleide_idechn,
		    settings_current.simpleide_master_file,
		    UI_MENU_ITEM_MEDIA_IDE_SIMPLE8BIT_MASTER_EJECT,
		    settings_current.simpleide_slave_file,
		    UI_MENU_ITEM_MEDIA_IDE_SIMPLE8BIT_SLAVE_EJECT );
  if( error ) return error;

  module_register( &simpleide_module_info );
  periph_register( PERIPH_TYPE_SIMPLEIDE, &simpleide_periph );

  return 0;
}

static void
simpleide_end( void )
{
  libspectrum_ide_free( simpleide_idechn );
}

void
simpleide_register_startup( void )
{
  startup_manager_module dependencies[] = {
    STARTUP_MANAGER_MODULE_DISPLAY,
    STARTUP_MANAGER_MODULE_SETUID
  };
  startup_manager_register( STARTUP_MANAGER_MODULE_SIMPLEIDE, dependencies,
                            ARRAY_SIZE( dependencies ), simpleide_init, NULL,
                            simpleide_end );
}

void
simpleide_reset( int hard_reset GCC_UNUSED )
{
  libspectrum_ide_reset( simpleide_idechn );
}

int
simpleide_insert( const char *filename, libspectrum_ide_unit unit )
{
  return ide_master_slave_insert(
    simpleide_idechn, unit, filename,
    &settings_current.simpleide_master_file,
    UI_MENU_ITEM_MEDIA_IDE_SIMPLE8BIT_MASTER_EJECT,
    &settings_current.simpleide_slave_file,
    UI_MENU_ITEM_MEDIA_IDE_SIMPLE8BIT_SLAVE_EJECT );
}

int
simpleide_commit( libspectrum_ide_unit unit )
{
  int error;

  error = libspectrum_ide_commit( simpleide_idechn, unit );

  return error;
}

int
simpleide_eject( libspectrum_ide_unit unit )
{
  return ide_master_slave_eject(
    simpleide_idechn, unit,
    &settings_current.simpleide_master_file,
    UI_MENU_ITEM_MEDIA_IDE_SIMPLE8BIT_MASTER_EJECT,
    &settings_current.simpleide_slave_file,
    UI_MENU_ITEM_MEDIA_IDE_SIMPLE8BIT_SLAVE_EJECT );
}

/* Port read/writes */


/* Data */
int logcount2=0;
libspectrum_byte simplecf_read_value;

static libspectrum_byte
simpleide_read( libspectrum_word port, libspectrum_byte *attached )
{
  libspectrum_ide_register idereg;
  
  *attached = 0xff; /* TODO: check this */
#if (IDE_MODE==0)  
  //original A8, A12, A13
  idereg = ( ( port >> 8 ) & 0x01 ) | ( ( port >> 11 ) & 0x06 );
// A13, A12, A8
  //idereg = ( ( port >> 6 ) & 0x04 ) | ( ( port >> 11 ) & 0x02 ) | ( ( port >> 13 ) & 0x01 );
#else
  #if (IDE_MODE==1)
    //A2, A6, A7
    idereg = ( ( port >> 2 ) & 0x01 ) | ( ( port >> 5 ) & 0x06 );
  #else
    //A3, A6, A7
    idereg = ( ( port >> 3 ) & 0x01 ) | ( ( port >> 5 ) & 0x06 );

  #endif
#endif  


  simplecf_read_value=libspectrum_ide_read( simpleide_idechn, idereg ); 
  
  dbg("%d, READ from CF IDE PORT=0x%04x, IDEREG=%d, val=%d (0x%02x)", logcount2, port,idereg,simplecf_read_value,simplecf_read_value);        
  logcount2++;  
  return simplecf_read_value;
}  

static void
simpleide_write( libspectrum_word port, libspectrum_byte data )
{
  libspectrum_ide_register idereg;
#if (IDE_MODE==0)   
  //original A8, A12, A13
  idereg = ( ( port >> 8 ) & 0x01 ) | ( ( port >> 11 ) & 0x06 );
  // A13, A12, A8
  //idereg = ( ( port >> 6 ) & 0x04 ) | ( ( port >> 11 ) & 0x02 ) | ( ( port >> 13 ) & 0x01 );

#else
  #if (IDE_MODE==1)   
    //A2, A6, A7
    idereg = ( ( port >> 2 ) & 0x01 ) | ( ( port >> 5 ) & 0x06 );
  #else
    //A3, A6, A7
    idereg = ( ( port >> 3 ) & 0x01 ) | ( ( port >> 5 ) & 0x06 );
  #endif  
#endif
    
  dbg("%d WRITE to CF IDE PORT=0x%04x,  IDEREG=%d, val=%d (0x%02x)", logcount2,port,idereg, data,data);    
  logcount2++;
  libspectrum_ide_write( simpleide_idechn, idereg, data ); 
}

static void
simpleide_snapshot_enabled( libspectrum_snap *snap )
{
  if( libspectrum_snap_simpleide_active( snap ) )
    settings_current.simpleide_active = 1;
}

static void
simpleide_to_snapshot( libspectrum_snap *snap )
{
  if( !settings_current.simpleide_active ) return;

  libspectrum_snap_set_simpleide_active( snap, 1 );
}
