/* if1_fdc.c: IF1 uPD765 floppy disk controller
   Copyright (c) 1999-2011 Philip Kendall, Darren Salt
   Copyright (c) 2012 Alex Badea

   $Id$

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   Alex: vamposdecampos@gmail.com

*/
#include <config.h>
#include <string.h>

#include "compat.h"
#include "memory_pages.h"
#include "module.h"
#include "options.h"
#include "periph.h"
#include "infrastructure/startup_manager.h"


#include "peripherals/if1.h"
#include "peripherals/disk/if1_fdc.h"

//#include "peripherals/disk/fdd.h"
#include "peripherals/disk/upd_fdc_2013.h"

#include "settings.h"
#include "ui/ui.h"
#include "ui/uimedia.h"

#if 1
  #include "z80/z80.h"
  #include "machines/debug_ro.h"
#else
  #define dbg(x...)
  #define dbgp(x...)
#endif


#define IF1_FDC_RAM_SIZE	1024    /* bytes */
#define IF1_NUM_DRIVES 2

int if1_fdc_available;

static upd_fdc_2013 *if1_fdc;
static fdd_t if1_drives[IF1_NUM_DRIVES];
static ui_media_drive_info_t if1_fdc_ui_drives[IF1_NUM_DRIVES];
static int deselect_event;

static int if1_fdc_memory_source;
static libspectrum_byte *if1_fdc_ram;
static memory_page if1_fdc_memory_map_romcs[MEMORY_PAGES_IN_16K];
/*SP overlayed memory source for the if-fdc ram would be better
static memory_page if1_fdc_memory_map_romcs_ram[ MEMORY_PAGES_IN_2K ];*/

int
if1_fdc_insert( if1_drive_number which, const char *filename, int autoload )
{
  if( which >= IF1_NUM_DRIVES ) {
    ui_error( UI_ERROR_ERROR, "if1_fdc_insert: unknown drive %d", which );
    fuse_abort(  );
  }

  return ui_media_drive_insert( &if1_fdc_ui_drives[ which ], filename, autoload );
}

fdd_t *
if1_fdc_get_fdd( if1_drive_number which )
{
  return &if1_drives[which];// SP .fdd;
}



void
if1_fdc_reset( int hard )
{
  const fdd_params_t *dt;
  int i;

  dbg("called hard=%d", hard );

  if1_fdc_available = 0;
  if( !periph_is_active( PERIPH_TYPE_INTERFACE1_FDC ) )
    return;

  dbg("loading ROM" );

  /* (re)load ROM */
  if( machine_load_rom_bank( if1_fdc_memory_map_romcs, 0,
			     settings_current.rom_hc_interface1,
			     settings_default.rom_hc_interface1,
			     0x4000 ) )              
    return;

  /*SP do not seem to matter*/
  //periph_activate_type(PERIPH_TYPE_INTERFACE1_FDC,0);
  //machine_current->ram.romcs = 0; 

  /* overlay RAM pages at the end of each of the two 8k ROM pages*/
  /*SP this was such a red herring, if I ever saw one.
  overlaying seems to work ok despite the FUSE changes in memory paging from 1k to 2k pages*/
  for( i = 0; i < MEMORY_PAGES_IN_8K; i++ ) {    
    libspectrum_word addr = i << (MEMORY_PAGE_SIZE_LOGARITHM);
    memory_page *page = &if1_fdc_memory_map_romcs[MEMORY_PAGES_IN_8K + i];

    //dbg("memory page: %d, num=%d, offset=%d",i,page->page_num, page->offset);

     if( !( addr & 0x800 ) )
       continue;
    
    page->source = if1_fdc_memory_source;//RAM memory source
    page->page = if1_fdc_ram + ( addr % IF1_FDC_RAM_SIZE );
    dbg("actual index:%d, address:%d, page offset=%d, page num: %d",i, addr,page->offset, page->page_num);            
    dbg("actual index:%d, address:%d, page offset=%d, page num: %d",i, addr,page->offset+IF1_FDC_RAM_SIZE, page->page_num);            
    page->writable = 1;
  }

  // for( i = 0; i < MEMORY_PAGES_IN_16K; i++ ) {
  //  libspectrum_word addr = i << (MEMORY_PAGE_SIZE_LOGARITHM+1);
  //   memory_page *page = &if1_fdc_memory_map_romcs[ i ];

  //    if( !( addr & 0x800 ) )
  //      continue;
  //   page->source = if1_fdc_memory_source;//RAM memory source       
  //   page->page = if1_fdc_ram +( addr % IF1_FDC_RAM_SIZE );
  //   page->offset = i * IF1_FDC_RAM_SIZE;
  //   dbg("memory page: %d, num=%d, offset=%d",i,page->page_num, page->offset);    
  //   page->writable = 1;     
  // }
 

  upd_fdc_2013_master_reset( if1_fdc );

  // dt = &fdd_params[option_enumerate_diskoptions_drive_if1_fdc_a_type(  ) + 1];  /* +1 => there is no `Disabled' */
  // fdd_init( &if1_drives[0], FDD_SHUGART, dt, 1 );

  // dt = &fdd_params[option_enumerate_diskoptions_drive_if1_fdc_b_type(  )];
  // fdd_init( &if1_drives[1], dt->enabled ? FDD_SHUGART : FDD_TYPE_NONE, dt, 1 );

  // dbg( "available" );


  for( i = 0; i < IF1_NUM_DRIVES; i++ ) {
    ui_media_drive_info_t *drive = &if1_fdc_ui_drives[ i ];
    dt = drive->get_params();
    fdd_motoron( drive->fdd, 0 );
    fdd_init( drive->fdd, dt->enabled ? FDD_SHUGART : FDD_TYPE_NONE, dt, 1 );
    fdd_motoron( drive->fdd, 1 );
  }

  /*SP needed to update menus, some will be disabled*/
  for( i = 0; i < IF1_NUM_DRIVES; i++ ) {
    ui_media_drive_update_menus( &if1_fdc_ui_drives[ i ],UI_MEDIA_DRIVE_UPDATE_ALL );
  }

  if1_fdc_available = 1;
  
  dbg( "active" );
}

void
if1_fdc_romcs( void )
{
  dbg( "called; if1_active=%d if1_fdc_available=%d", if1_active, if1_fdc_available );
  /*SP I was hoping this will help paging hc-if1-fdc in but alas it is not enough to make if1-fdc work while if1 active*/
  if( !if1_active || !if1_fdc_available )
    return;
  /*SP updated*/
  //memory_map_romcs_16k( 0x0000, if1_fdc_memory_map_romcs );
  memory_map_romcs_full(if1_fdc_memory_map_romcs);  
}

void
if1_fdc_activate( void )
{
  dbg( "called" );
}


libspectrum_byte
if1_fdc_status( libspectrum_word port GCC_UNUSED, libspectrum_byte *attached )
{
  libspectrum_byte ret;

  *attached = 1;
  ret = upd_fdc_2013_read_status( if1_fdc );
  dbg( "port 0x%02x --> 0x%02x", port & 0xff, ret );
  return ret;
}

libspectrum_byte
if1_fdc_read( libspectrum_word port GCC_UNUSED, libspectrum_byte *attached )
{
  libspectrum_byte ret;

  *attached = 1;
  ret = upd_fdc_2013_read_data( if1_fdc );
  dbg( "port 0x%02x --> 0x%02x", port & 0xff, ret );
  return ret;
}

void
if1_fdc_write( libspectrum_word port GCC_UNUSED, libspectrum_byte data )
{
  dbg( "port 0x%02x <-- 0x%02x", port & 0xff, data );
  upd_fdc_2013_write_data( if1_fdc, data );
}

libspectrum_byte
if1_fdc_sel_read( libspectrum_word port GCC_UNUSED, libspectrum_byte *attached )
{
  libspectrum_byte ret;
  int i;

  *attached = 1;
  ret = 0xff;
  for( i = 0; i < IF1_NUM_DRIVES; i++ )
    if( if1_drives[i].motoron )
      ret &= ~1;
  dbg( "port 0x%02x --> 0x%02x", port & 0xff, ret );
  return ret;
}

void
if1_fdc_sel_write( libspectrum_word port GCC_UNUSED, libspectrum_byte data )
{
  libspectrum_byte armed;

  dbg( "port 0x%02x <-- 0x%02x", port & 0xff, data );

  if( !( data & 0x10 ) ) {
    dbg( "FDC reset" );
    upd_fdc_2013_master_reset( if1_fdc );
  }
  upd_fdc_2013_tc( if1_fdc, data & 1 );

  event_remove_type( deselect_event );

  armed = data & 0x08; 
  if( armed ) {
    fdd_select( &if1_drives[0], armed && ( data & 0x02 ) );
    fdd_select( &if1_drives[1], armed && ( data & 0x04 ) );
    fdd_motoron( &if1_drives[0], armed && ( data & 0x02 ) );
    fdd_motoron( &if1_drives[1], armed && ( data & 0x04 ) );
  }
  else {
    /* The IF1 contains a 555 timer configured as a retriggerable
     * monostable.  It uses a 470 kOhm resistor and 3.3 uF capacitor.
     * This should give a delay of approximately 1.7 seconds.
     */
    event_add( tstates + 17 * machine_current->timings.processor_speed / 10, deselect_event );
  }

  /*SP FDD should be the one doing the UI update
  ui_statusbar_update( UI_STATUSBAR_ITEM_DISK, armed ? UI_STATUSBAR_STATE_ACTIVE : UI_STATUSBAR_STATE_INACTIVE );*/
}

static void
if1_deselect_cb( libspectrum_dword last_tstates, int type, void *user_data )
{
  dbg( "called" );
  fdd_select( &if1_drives[0], 0 );
  fdd_select( &if1_drives[1], 0 );
  fdd_motoron( &if1_drives[0], 0 );
  fdd_motoron( &if1_drives[1], 0 );

}

static periph_port_t if1_fdc_ports[] = {
  //sel ports are EF and F7
  {0x00fd, 0x0005, if1_fdc_sel_read, if1_fdc_sel_write},
  {0x00ff, 0x0085, if1_fdc_status, NULL},
  {0x00ff, 0x0087, if1_fdc_read, if1_fdc_write},
  {0, 0, NULL, NULL,},
};



/*SP modified*/
static periph_t if1_fdc_periph = {
  /*.option = */&settings_current.interface1_fdc,
  /*.ports = */if1_fdc_ports,
  /*.hard_reset*/1,
  /*.activate = */if1_fdc_activate,
};

static module_info_t if1_fdc_module_info = {
  /*.reset = */if1_fdc_reset,
  /*.romcs = */if1_fdc_romcs,
};

int
if1_fdc_init(  void *context  )
{
  int i;

  if1_fdc_memory_source = memory_source_register( "If1 RAM" );
  if1_fdc_ram = memory_pool_allocate_persistent( IF1_FDC_RAM_SIZE, 1 );

  if1_fdc = upd_fdc_2013_alloc_fdc( UPD765A, UPD_CLOCK_8MHZ );
  if1_fdc->current_drive = NULL;/*SP*/
  if1_fdc->drive[0] = &if1_drives[0];
  if1_fdc->drive[1] = &if1_drives[1];
  if1_fdc->drive[2] = &if1_drives[0];
  if1_fdc->drive[3] = &if1_drives[1];

  fdd_init( &if1_drives[0], FDD_SHUGART, &fdd_params[4], 0 );
  fdd_init( &if1_drives[1], FDD_SHUGART, NULL, 0 ); /* drive geometry 'autodetect' */
  if1_fdc->set_intrq = NULL;
  if1_fdc->reset_intrq = NULL;
  if1_fdc->set_datarq = NULL;
  if1_fdc->reset_datarq = NULL;
  /*SP*/
  if1_drives[0].disk.flag = DISK_FLAG_NONE;
  if1_drives[1].disk.flag = DISK_FLAG_NONE;
  if1_fdc->current_drive=&if1_drives[0];

  deselect_event = event_register( if1_deselect_cb, "IF1 FDC deselect" );

  module_register( &if1_fdc_module_info );
  periph_register( PERIPH_TYPE_INTERFACE1_FDC, &if1_fdc_periph );

  for( i = 0; i < IF1_NUM_DRIVES; i++ ) {
    if1_fdc_ui_drives[ i ].fdd = &if1_drives[ i ];
    /*SP*/
    ui_media_drive_register( &if1_fdc_ui_drives[ i ] );
  }

return 0;  
}

void
if1_fdc_end( void )
{
  //does nothing
}

void
if1_fdc_register_startup( void )
{
  startup_manager_module dependencies[] = {
    STARTUP_MANAGER_MODULE_DEBUGGER,
    STARTUP_MANAGER_MODULE_MEMORY,
    STARTUP_MANAGER_MODULE_EVENT,    
    //STARTUP_MANAGER_MODULE_IF1,
    STARTUP_MANAGER_MODULE_SETUID,
  };
  startup_manager_register( STARTUP_MANAGER_MODULE_IF1_FDC, dependencies,
                            ARRAY_SIZE( dependencies ), if1_fdc_init, NULL,
                            if1_fdc_end );
}


static int
ui_drive_is_available( void )
{
  return if1_fdc_available;
}

static const fdd_params_t *
ui_drive_get_params_1( void )
{
  return &fdd_params[ option_enumerate_diskoptions_drive_if1_fdc_a_type()+1];	/* +1 => there is no `Disabled' */
}

static const fdd_params_t *
ui_drive_get_params_2( void )
{
  return &fdd_params[ option_enumerate_diskoptions_drive_if1_fdc_b_type() ];
}

// static int
// ui_drive_autoload( void )
// {
//   machine_reset( 0 );
//   phantom_typist_activate_disk();
//   return 0;
// }

static int
ui_drive_inserted( const ui_media_drive_info_t *drive, int new) //, int loaded 
{
  dbg("if1 FDC inserted Disk %s", drive->fdd->disk.filename);
  //if( loaded ) 
  {
    fdd_motoron( drive->fdd, 0 );
    fdd_motoron( drive->fdd, 1 );
  }
  return 0;
}

static ui_media_drive_info_t if1_fdc_ui_drives[ IF1_NUM_DRIVES ] = {
  {
    /*.name = */"HC Interface 1/Drive 1",
    /*.controller_index =*/ UI_MEDIA_CONTROLLER_IF1_FDC,
    /*.drive_index = */IF1_DRIVE_1,
    /*.menu_item_parent = */UI_MENU_ITEM_MEDIA_DISK_IF1_FDC,
    /*.menu_item_top = */   UI_MENU_ITEM_MEDIA_DISK_IF1_FDC_A,
    /*.menu_item_eject = */ UI_MENU_ITEM_MEDIA_DISK_IF1_FDC_A_EJECT,
    /*.menu_item_flip = */  UI_MENU_ITEM_MEDIA_DISK_IF1_FDC_A_FLIP_SET,
    /*.menu_item_wp = */    UI_MENU_ITEM_MEDIA_DISK_IF1_FDC_A_WP_SET,
    /*.is_available = */&ui_drive_is_available,
    /*.get_params = */&ui_drive_get_params_1,//renamed from a
    /*.insert_hook = */&ui_drive_inserted,
    /* .autoload_hook =  &ui_drive_autoload, */NULL
  },
  {
    /*.name = */"HC Interface 1/Drive 2",
    /*.controller_index =*/ UI_MEDIA_CONTROLLER_IF1_FDC,
    /*.drive_index =*/ IF1_DRIVE_2,
    /*.menu_item_parent = */UI_MENU_ITEM_MEDIA_DISK_IF1_FDC,
    /*.menu_item_top = */   UI_MENU_ITEM_MEDIA_DISK_IF1_FDC_B,
    /*.menu_item_eject = */ UI_MENU_ITEM_MEDIA_DISK_IF1_FDC_B_EJECT,
    /*.menu_item_flip = */  UI_MENU_ITEM_MEDIA_DISK_IF1_FDC_B_FLIP_SET,
    /*.menu_item_wp = */    UI_MENU_ITEM_MEDIA_DISK_IF1_FDC_B_WP_SET,
    /*.is_available =*/ &ui_drive_is_available,
    /*.get_params =*/ &ui_drive_get_params_2,//renamed from b
    /*.insert_hook = */&ui_drive_inserted,
    /* .autoload_hook =  &ui_drive_autoload, */NULL  
  },  
};
