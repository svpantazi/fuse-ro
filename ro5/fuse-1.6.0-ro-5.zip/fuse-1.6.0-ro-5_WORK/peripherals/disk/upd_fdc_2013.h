/* upd_fdc_2013.h: NEC floppy disk controller emulation
   Copyright (c) 2003-2013 Stuart Brady, Fredrick Meunier, Philip Kendall,
   Gergely Szasz

   $Id$

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   Philip: philip-fuse@shadowmagic.org.uk

   Stuart: stuart.brady@gmail.com

*/

#ifndef FUSE_UPD_FDC_2013_H
#define FUSE_UPD_FDC_2013_H

#include <libspectrum.h>

#include "event.h"
#include "fdd.h"
#include "fuse.h"

#include "upd_fdc.h"/*SP because of hack!*/


typedef upd_fdc upd_fdc_2013;/*SP alias so now they are the same structure*/

void upd_fdc_2013_init_events( void );

/* allocate an fdc */
upd_fdc_2013 *upd_fdc_2013_alloc_fdc( upd_type_t type, upd_clock_t clock );
void upd_fdc_2013_master_reset( upd_fdc_2013 *f );

/*SP specific to 2013*/
void upd_fdc_2013_tc( upd_fdc_2013 *f, int tc );

libspectrum_byte upd_fdc_2013_read_status( upd_fdc_2013 *f );

libspectrum_byte upd_fdc_2013_read_data( upd_fdc_2013 *f );
void upd_fdc_2013_write_data( upd_fdc_2013 *f, libspectrum_byte b );

#endif                  /* #ifndef FUSE_UPD_FDC_2013_H */
