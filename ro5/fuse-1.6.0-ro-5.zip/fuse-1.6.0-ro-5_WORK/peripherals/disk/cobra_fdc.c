/* cobra_fdc.c: CoBra uPD765 floppy disk controller
   Copyright (c) 1999-2011 Philip Kendall, Darren Salt
   Copyright (c) 2012-2013 Alex Badea

   $Id$

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   Alex: vamposdecampos@gmail.com




  modified by SP to work with recent upd_fdc_2013 code

*/
#include <config.h>
#include <string.h>

//#include <libspectrum.h>
#include "module.h"
#include "options.h"
#include "periph.h"
#include "infrastructure/startup_manager.h"
#include "peripherals/disk/cobra_fdc.h"
//#include "peripherals/disk/fdd.h"
#include "peripherals/disk/upd_fdc_2013.h"
#include "settings.h"
#include "ui/ui.h"
#include "ui/uimedia.h"


#include "z80/z80.h" //for processing interrupt vector 

#if 0  
  #include "machines/debug_ro.h"
#else
#define dbg(x...)
#define dbgp(x...)
#endif

#define COBRA_NUM_DRIVES 4

struct cobra_ctc {
  libspectrum_byte control_word;
  libspectrum_byte time_constant;
  libspectrum_byte vector;
  libspectrum_byte counter;
  unsigned trigger_pin:1;
  unsigned zc:1;
  unsigned intr:1;
};

static upd_fdc_2013 *cobra_fdc;

static fdd_t  cobra_drives[COBRA_NUM_DRIVES];
static ui_media_drive_info_t cobra_ui_drives[ COBRA_NUM_DRIVES ];
static struct cobra_ctc cobra_ctc[4];

int cobra_fdc_available;

int ctc_int_event;
int cobra_fdc_frame_interrupt_event;//SP new

/*
 * Z80-CTC
 *
 * CLK/TRG0 <- i8272 INT
 * CLK/TRG1 <- ZC0
 * CLK/TRG2 <- ZC1
 * i8272 TC <- ZC2
 * CLK/TRG3 <- TRG3 (frame interrupt?)
 *
 * => channels <2(MSB), 1, 0(LSB)> count i8272 data bytes
 */

static libspectrum_byte
cobra_ctc_read( libspectrum_word port, libspectrum_byte *attached )
{
  int channel = (port >> 3) & 3;
  struct cobra_ctc *ctc = &cobra_ctc[channel];

  dbg("ctc port 0x%02x read: channel %d counter %d", port & 0xff, channel, ctc->counter);
  *attached = 1;
  return ctc->counter;
}

/* CTC control word bits */
#define Z80_CTC_CONTROL_INTR_EN		    0x80	/* interrupt enable */
#define Z80_CTC_CONTROL_COUNTER_MODE	0x40	/* counter mode; timer mode if clear */
#define Z80_CTC_CONTROL_PRESCALER_256	0x20	/* /256 prescaler; /16 if clear */
#define Z80_CTC_CONTROL_RISING_EDGE	  0x10	/* trigger on rising edge */
#define Z80_CTC_CONTROL_WAIT_TRG	    0x08	/* autostart timer if clear */
#define Z80_CTC_CONTROL_TIME_CONST	  0x04	/* time constant follows */
#define Z80_CTC_CONTROL_RESET		      0x02	/* software reset */
#define Z80_CTC_CONTROL_CONTROL		    0x01	/* control word; vector if clear */

static void
cobra_ctc_write( libspectrum_word port, libspectrum_byte b )
{
  int channel = (port >> 3) & 3;
  struct cobra_ctc *ctc = &cobra_ctc[channel];
  dbg("%p ctc port 0x%02x chan %d <- 0x%02x", ctc, port & 0xff, channel, b );
  if( ctc->control_word & Z80_CTC_CONTROL_TIME_CONST ) {

    ctc->control_word &= ~Z80_CTC_CONTROL_TIME_CONST;
    ctc->control_word &= ~Z80_CTC_CONTROL_RESET;
    ctc->time_constant = b;
    ctc->counter = b; //SP same thing as ctc->time_constant;
    ctc->zc = 0; //ctc->counter == 0;
    ctc->intr = 0;

    dbg("channel %d time constant 0x%x / %d", channel, b, b);
    //SP why set this again?
    //if( channel == 3 && ( ctc->control_word & Z80_CTC_CONTROL_INTR_EN ))
    //  machine_current->timings.interrupt_length = libspectrum_timings_interrupt_length( machine_current->machine );

  } else if ( b & Z80_CTC_CONTROL_CONTROL ) {
    ctc->control_word = b;
    dbg( "channel %d %s%s%s%s%s%s%s%s", channel,
      (b & 0x80) ? "int " : "",
      (b & 0x40) ? "counter " : "timer ",
      (b & 0x20) ? "/256 " : "/16 ",
      (b & 0x10) ? "rising " : "falling ",
      (b & 0x08) ? " " : "auto-trigger ",
      (b & 0x04) ? "time-constant " : "",
      (b & 0x02) ? "reset " : "",
      (b & 0x01) ? "control " : "vector "
    );
    if( b & Z80_CTC_CONTROL_RESET ) {
      ctc->zc = 0;
      ctc->intr = 0;
    }
  } else {
    dbg("channel %d vector 0x%02x", channel, b);
    for( channel = 0; channel < 4; channel++ )
      cobra_ctc[ channel ].vector = b;
  }
}

static void
ctc_trigger( struct cobra_ctc *ctc, int trigger )
{
  if( ctc->control_word & Z80_CTC_CONTROL_RESET ) {
    dbg("XXXX channel %p in reset", ctc);
    ctc->trigger_pin = trigger;
    return;
  }
  if( trigger && !ctc->trigger_pin ) {
    ctc->counter--;
    dbg( "%p new counter: %d", ctc, ctc->counter );
    ctc->zc = ctc->counter == 0;
    if( ctc->zc ) {
      ctc->counter = ctc->time_constant;
      dbg( "%p ZC: new counter: %d", ctc, ctc->counter );
      if( ctc->control_word & Z80_CTC_CONTROL_INTR_EN ) {
        ctc->intr = 1;
      }
      event_add( tstates + 1, ctc_int_event );
      //event_add( tstates + 96, ctc_int_event );
    }
  }
  ctc->trigger_pin = trigger;
  /*SP this appears too a frequent update of the disk icon - win10 hates it
  ui_statusbar_update( UI_STATUSBAR_ITEM_DISK, trigger ? UI_STATUSBAR_STATE_ACTIVE : UI_STATUSBAR_STATE_INACTIVE ); */
}


//SP ATTENTION here  vector control - used by COBRA CPM
static void
ctc_int_fn( libspectrum_dword tstates, int type, void *user_data )
{
  int chan;

  //upd_fdc_2013_tc( cobra_fdc, cobra_ctc[ 2 ].zc );

  for( chan = 0; chan < 4; chan++ ) {
    struct cobra_ctc *ctc = &cobra_ctc[ chan ];
    if( ctc->intr ) {
        libspectrum_byte vector = (ctc->vector & 0xf8) | (chan << 1);
        dbg( "%p interrupt! vector register 0x%02x, vector 0x%02x", ctc, ctc->vector, vector );                
        /*SP commented out: */
        if( !z80_vectored_interrupt( vector ) ) { 
        //if( !z80_interrupt( ) ) { /*SP assume vector always 0xff*/
          dbg("defer");
          event_add( tstates + 10, ctc_int_event );
        } else {
          dbg("accepted");
          ctc->intr = 0;
        }
    }
  }
}


//fdc

static void
cobra_fdc_set_intrq( upd_fdc_2013 *f )
{
  int old_zc = cobra_ctc[2].zc;
  ctc_trigger( &cobra_ctc[0], 1 );
  if( cobra_ctc[0].zc ) {
    ctc_trigger( &cobra_ctc[1], 1 );
    ctc_trigger( &cobra_ctc[1], 0 );
  }
  if( cobra_ctc[1].zc ) {
    ctc_trigger( &cobra_ctc[2], 1 );
    ctc_trigger( &cobra_ctc[2], 0 );
  }
  if( f && !old_zc && cobra_ctc[2].zc )
    upd_fdc_2013_tc( f, 1 );
}

static void
cobra_fdc_reset_intrq( upd_fdc_2013 *f )
{
  ctc_trigger( &cobra_ctc[0], 0 );
}


//static int
//cobra_fdc_frame_interrupt( void )
static void
cobra_fdc_frame_interrupt_fn( libspectrum_dword tstates, int type, void *user_data )
{
  /* only allow interrupts in Basic mode */
  //if( !machine_current->ram.special ) 
  {
    ctc_trigger( &cobra_ctc[3], 1 );
    ctc_trigger( &cobra_ctc[3], 0 );
    dbg("INT!");
    //retrigger
     //if(!z80.iff1) 
     {    
       //SP retrigerring event does not seem to make a difference for CPM loading!              
      event_add( tstates+ machine_current->timings.tstates_per_frame, cobra_fdc_frame_interrupt_event);
     }
    //return 1;
    //return 0;
  }
  //return machine_current->ram.special ? 1 : 0;
}

int
cobra_fdc_insert( cobra_drive_number which, const char *filename, int autoload )
{
  if( which >= COBRA_NUM_DRIVES ) {
    ui_error( UI_ERROR_ERROR, "cobra_fdc_insert: unknown drive %d", which );
    fuse_abort(  );
  }
  dbg("Inserted Disk %s \n", cobra_ui_drives[ which ].fdd->disk.filename);
  return ui_media_drive_insert( &cobra_ui_drives[ which ], filename, autoload );
}

fdd_t *
cobra_get_fdd(cobra_drive_number which)
{
  return &(cobra_drives[which]);/*SP changed */
}

void
cobra_fdc_activate( void )
{
  dbg( "called" );
}

libspectrum_byte
cobra_fdc_status( libspectrum_word port, libspectrum_byte *attached )
{
  libspectrum_byte ret;
  static libspectrum_byte last = 0;

  *attached = 1;
  ret = upd_fdc_2013_read_status( cobra_fdc );
  if( last != ret ) {
    dbg( "port 0x%02x --> 0x%02x", port & 0xff, ret );
    last = ret;
  }
  return ret;
}

libspectrum_byte
cobra_fdc_read( libspectrum_word port, libspectrum_byte *attached )
{
  libspectrum_byte ret;

  *attached = 1;
  ret = upd_fdc_2013_read_data( cobra_fdc );
  dbg( "port 0x%02x --> 0x%02x", port & 0xff, ret );
  /*SP update here */
  ui_statusbar_update( UI_STATUSBAR_ITEM_DISK,(!cobra_fdc->tc) ? UI_STATUSBAR_STATE_ACTIVE : UI_STATUSBAR_STATE_INACTIVE );
  return ret;
}

void
cobra_fdc_write( libspectrum_word port, libspectrum_byte b )
{
  dbg( "port 0x%02x <-- 0x%02x", port & 0xff, b );
  upd_fdc_2013_write_data( cobra_fdc, b );  
}


static void cobra_fdc_reset( int hard );

static module_info_t cobra_fdc_module = {
  /*.reset = */cobra_fdc_reset,
};


/*cobra fdc moved from cobra_fdc.c */
static const periph_port_t cobra_fdc_ports[] = {
/* CPU A1 -> 8272 nCS;  CPU A3 -> 8272 A0 
  out $FD - 8272 commands                 ;HC88   $DF 
  in $FD	- 8272 status data		          ;HC88 - $DD
  in $F5	 8272 Status Register  */       //HC88 - $DD 
                                          //HC88 - timer control - out  E7h
  //{ 0x000a, 0x0000, cobra_fdc_status, NULL },
  //{ 0x000a, 0x0008, cobra_fdc_read, cobra_fdc_write },  
  //SP fully decode port
    { 0x00ff, 0x00f5, cobra_fdc_status, NULL },//in form basic
    { 0x00ff, 0x00fd, cobra_fdc_read, cobra_fdc_write },  //in, out from basic,

    
  /* CPU A2 -> Z80-CTC nCE 
  out $E3 CTC Channel 0, specify int. vector = 00000cc0
  OUT $EB	; CTC-1
  OUT $F3 ; CTC-2    
  ??  $FB no CTC4
; Interrupt service routine addresses are located at:
; CTC-0 -> F000, CTC-1 -> F002, CTC-2 -> F004, CTC-3 -> F006
  F002					CTC-1 INT. SVC. ADDR
; F003					CTC-1 INT. SVC. ADDR
; F004					CTC-2 INT. SVC. ADDR
; F005					CTC-2 INT. SVC. ADDR
; F006					CTC-3 INT. SVC. ADDR
; F007					CTC-3 INT. SVC. ADDR  */

  //{ 0x0004, 0x0000, cobra_ctc_read, cobra_ctc_write },
  //to  WORK make sure mask is appropriate!!
   { 0x00ff, 0x00e3, cobra_ctc_read, cobra_ctc_write },//in, out from basic, ld a, $57 then out
   { 0x00ff, 0x00eb, cobra_ctc_read, cobra_ctc_write },//out from basic, ld a, $57 then out
   { 0x00ff, 0x00f3, cobra_ctc_read, cobra_ctc_write },//out from basic, ld a, $57 then out
  { 0x00ff, 0x00fb, cobra_ctc_read, cobra_ctc_write },  //in, out from basic,  ld      a,04h , out  (0fbh),a

  { 0, 0, NULL, NULL }
};

static const periph_t cobra_fdc_periph = {
  /*.option = */ &settings_current.cobra_fdc,
  /*.ports = */cobra_fdc_ports,
  /*.hardreset */ 1,
  /*.activate = */cobra_fdc_activate
};


static void
cobra_fdc_select_drive( int i )
{
  if( cobra_fdc->current_drive != &cobra_drives[ i & 0x03 ]) {
    if( cobra_fdc->current_drive != NULL )
      fdd_select( cobra_fdc->current_drive, 0 );
    cobra_fdc->current_drive = &cobra_drives[ i & 0x03 ];
    fdd_select( cobra_fdc->current_drive, 1 );
  }  
}

static int
cobra_fdc_init( void *context  )
{
  int i;
  fdd_t *d;

  ctc_int_event = event_register( ctc_int_fn, "CoBra CTC interrupt" );
  
  //SP new
  cobra_fdc_frame_interrupt_event=event_register( cobra_fdc_frame_interrupt_fn, "CoBra FDC frame interrupt" );

  cobra_fdc = upd_fdc_2013_alloc_fdc( UPD765A, UPD_CLOCK_8MHZ );
  cobra_fdc->current_drive = NULL;

  cobra_fdc->drive[0] = &cobra_drives[2];
  cobra_fdc->drive[1] = &cobra_drives[3];
  cobra_fdc->drive[2] = &cobra_drives[0];
  cobra_fdc->drive[3] = &cobra_drives[1];
  cobra_fdc->set_intrq = cobra_fdc_set_intrq;
  cobra_fdc->reset_intrq = cobra_fdc_reset_intrq;
  cobra_fdc->set_datarq = NULL;
  cobra_fdc->reset_datarq = NULL;

  for( i = 0; i < COBRA_NUM_DRIVES; i++ ) {
    d=&cobra_drives[ i ];
    fdd_init( d, FDD_SHUGART, NULL, 0 );
    d->disk.flag = DISK_FLAG_NONE;
    //register UI drives
    cobra_ui_drives[ i ].fdd = d;     
    ui_media_drive_register( &cobra_ui_drives[ i ] );    
  }

  //cobra_fdc_select_drive( 0 );
  module_register( &cobra_fdc_module );
  periph_register( PERIPH_TYPE_COBRA_FDC, &cobra_fdc_periph );  
  return 0;
}

void
cobra_fdc_reset( int hard )
{
  const fdd_params_t *dt;
  int i;

  dbg("called hard=%d", hard );

  cobra_fdc_available = 0;
  if( !periph_is_active( PERIPH_TYPE_COBRA_FDC ) )
    return;

  memset(cobra_ctc, 0, sizeof(cobra_ctc));

  upd_fdc_2013_master_reset( cobra_fdc );

  for( i = 0; i < COBRA_NUM_DRIVES; i++ ) {
    ui_media_drive_info_t *drive = &cobra_ui_drives[ i ];
    dt = drive->get_params();
    fdd_motoron( drive->fdd, 0 );
    fdd_init( drive->fdd, dt->enabled ? FDD_SHUGART : FDD_TYPE_NONE, dt, 1 );
    fdd_motoron( drive->fdd, 1 );
  }

  for( i = 0; i < COBRA_NUM_DRIVES; i++ ) {
    ui_media_drive_update_menus( &cobra_ui_drives[ i ], UI_MEDIA_DRIVE_UPDATE_ALL );
  }

  cobra_fdc_select_drive( 0 );

  /*reset CTC */
  for(i = 0; i < 4; i++ ) {
    struct cobra_ctc *ctc = &cobra_ctc[ i ];
    memset(ctc, 0, sizeof(*ctc));
    ctc->control_word = Z80_CTC_CONTROL_RESET;
  }

  /*SP no more frame interrupt hack*/
  //machine_current->frame_interrupt = cobra_fdc_frame_interrupt;
  //SP 
  event_add(machine_current->timings.tstates_per_frame, cobra_fdc_frame_interrupt_event);

  cobra_fdc_available = 1;
  dbg( "active" );
}

void
cobra_fdc_end( void )
{
  cobra_fdc_available=0;
  //libspectrum_free(cobra_fdc);
}

void
cobra_fdc_register_startup( void )
{
  startup_manager_module dependencies[] = {
    STARTUP_MANAGER_MODULE_DEBUGGER,
    STARTUP_MANAGER_MODULE_MEMORY,
    STARTUP_MANAGER_MODULE_EVENT,
    STARTUP_MANAGER_MODULE_SETUID,
  };
  startup_manager_register( STARTUP_MANAGER_MODULE_COBRA_FDC, dependencies,
                            ARRAY_SIZE( dependencies ), cobra_fdc_init, NULL,
                            cobra_fdc_end );
}



static int
ui_drive_is_available( void )
{
  return cobra_fdc_available;
}

static const fdd_params_t *
ui_drive_get_params_a( void )
{
  return &fdd_params[ option_enumerate_diskoptions_drive_cobra_fdc_a_type() ];
}

static const fdd_params_t *
ui_drive_get_params_b( void )
{
  return &fdd_params[ option_enumerate_diskoptions_drive_cobra_fdc_b_type() ];
}

static const fdd_params_t *
ui_drive_get_params_c( void )
{
  return &fdd_params[ option_enumerate_diskoptions_drive_cobra_fdc_c_type() ];
}

static const fdd_params_t *
ui_drive_get_params_d( void )
{
  return &fdd_params[ option_enumerate_diskoptions_drive_cobra_fdc_d_type() ];
}

static int
ui_drive_inserted( const ui_media_drive_info_t *drive, int new) //, int loaded 
{
  dbg("Cobra FDC inserted Disk %s", drive->fdd->disk.filename);
  //if( loaded ) 
  {
    fdd_motoron( drive->fdd, 0 );
    fdd_motoron( drive->fdd, 1 );
  }
  return 0;
}

static ui_media_drive_info_t cobra_ui_drives[ COBRA_NUM_DRIVES ] = {
  {
    /*.name = */"CoBra/Drive A:",
    /*.controller_index =*/ UI_MEDIA_CONTROLLER_COBRA_FDC,
    /*.drive_index = */COBRA_DRIVE_A,
    /*.*menu_item_parent = */UI_MENU_ITEM_MEDIA_DISK_COBRA,
    /*.menu_item_top = */UI_MENU_ITEM_MEDIA_DISK_COBRA_A,
    /*.menu_item_eject = */UI_MENU_ITEM_MEDIA_DISK_COBRA_A_EJECT,
    /*.menu_item_flip = */UI_MENU_ITEM_MEDIA_DISK_COBRA_A_FLIP_SET,
    /*.menu_item_wp = */UI_MENU_ITEM_MEDIA_DISK_COBRA_A_WP_SET,
    /*.is_available = */&ui_drive_is_available,
    /*.get_params = */&ui_drive_get_params_a,
    /*.insert_hook = */&ui_drive_inserted,
    /* .autoload_hook =  &ui_drive_autoload, */NULL
  },
  {
    /*.name = */"CoBra/Drive B:",
    /*.controller_index =*/ UI_MEDIA_CONTROLLER_COBRA_FDC,
    /*.drive_index =*/ COBRA_DRIVE_B,
    /*.menu_item_parent =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA,
    /*.menu_item_top =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_B,
    /*.menu_item_eject =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_B_EJECT,
    /*.menu_item_flip =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_B_FLIP_SET,
    /*.menu_item_wp =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_B_WP_SET,
    /*.is_available =*/ &ui_drive_is_available,
    /*.get_params =*/ &ui_drive_get_params_b,
    /*.insert_hook = */&ui_drive_inserted,
    /* .autoload_hook =  &ui_drive_autoload, */NULL  },
  {
    /*.name =*/ "CoBra/Drive C:",
    /*.controller_index =*/ UI_MEDIA_CONTROLLER_COBRA_FDC,
    /*.drive_index =*/ COBRA_DRIVE_C,
    /*.menu_item_parent =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA,
    /*.menu_item_top =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_C,
    /*.menu_item_eject =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_C_EJECT,
    /*.menu_item_flip =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_C_FLIP_SET,
    /*.menu_item_wp =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_C_WP_SET,
    /*.is_available =*/ &ui_drive_is_available,
    /*.get_params =*/ &ui_drive_get_params_c,
    /*.insert_hook = */&ui_drive_inserted,
    /* .autoload_hook =  &ui_drive_autoload, */NULL
  },
  {
    /*.name =*/ "CoBra/Drive D:",
    /*.controller_index =*/ UI_MEDIA_CONTROLLER_COBRA_FDC,
    /*.drive_index =*/ COBRA_DRIVE_D,
    /*.menu_item_parent =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA,
    /*.menu_item_top =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_D,
    /*.menu_item_eject =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_D_EJECT,
    /*.menu_item_flip =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_D_FLIP_SET,
    /*.menu_item_wp =*/ UI_MENU_ITEM_MEDIA_DISK_COBRA_D_WP_SET,
    /*.is_available =*/ &ui_drive_is_available,
    /*.get_params =*/ &ui_drive_get_params_d,
    /*.insert_hook = */&ui_drive_inserted,
    /* .autoload_hook =  &ui_drive_autoload, */NULL
  },
};

