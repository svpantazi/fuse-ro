/* rksspec.c: R. Koning SuperSpec specific routines
    adapted by S.V. Pantazi from 
   Spectrum 48K specific routines
   Copyright (c) 1999-2011 Philip Kendall

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   E-mail: philip-fuse@shadowmagic.org.uk

*/

#include <config.h>

#include <stdio.h>

#include <libspectrum.h>

#include "machine.h"
#include "machines_periph.h"
#include "memory_pages.h"
#include "periph.h"
#include "peripherals/disk/beta.h"
#include "settings.h"
#include "cobra1.h"
#include "spec128.h"
#include "rksspec.h"
#include "spectrum.h"

#if 0
  #include "z80/z80.h"
  #include "machines/debug_ro.h"
#else
  #define dbg(x...)
  #define dbgp(x...)
#endif

static int rom_idx,ram_idx;

static int rksspec_reset( void );

int rksspec_port_from_ula( libspectrum_word port )
{
  /* All even ports supplied by ULA */
  return 0;//!( port & 0x0001 );
}

int rksspec_init( fuse_machine_info *machine )
{
  machine->machine = LIBSPECTRUM_MACHINE_RKSSPEC;
  machine->id = "rksspec";

  machine->reset = rksspec_reset;

  machine->timex = 0;
  machine->ram.port_from_ula         = rksspec_port_from_ula;
  machine->ram.contend_delay	     = spectrum_contend_delay_65432100;
  machine->ram.contend_delay_no_mreq = spectrum_contend_delay_65432100;
  machine->ram.valid_pages	     = 4;

  machine->unattached_port =spectrum_unattached_port_none; //spectrum_unattached_port;

  machine->shutdown = NULL;

  machine->memory_map = rksspec_memory_map;

  return 0;
}

static int
rksspec_reset( void )
{
  int error;

  error = machine_load_rom( 0, settings_current.rom_rksspec_224, settings_default.rom_rksspec_224, 0x4000 );
  if( error ) return error;
  error = machine_load_rom( 1, settings_current.rom_rksspec_225, settings_default.rom_rksspec_225, 0x4000 );
  if( error ) return error;
  error = machine_load_rom( 2, settings_current.rom_rksspec_226, settings_default.rom_rksspec_226, 0x4000 );
  if( error ) return error;
  error = machine_load_rom( 3, settings_current.rom_rksspec_227, settings_default.rom_rksspec_227, 0x4000 );
  if( error ) return error;

  periph_clear();
  machines_periph_48();

  periph_set_present( PERIPH_TYPE_RKSSPEC_MEMORY, PERIPH_PRESENT_ALWAYS );
  periph_set_present( PERIPH_TYPE_KEMPSTON, PERIPH_PRESENT_ALWAYS );
  periph_set_present( PERIPH_TYPE_CFMEM, PERIPH_PRESENT_ALWAYS );

/* memory  configuration bits*/

  periph_update();

  beta_builtin = 0;

  memory_current_screen = 5;
  memory_screen_mask = 0xffff;

  rksspec_common_display_setup();

  return rksspec_common_reset();
}

void
rksspec_common_display_setup( void )
{
  display_dirty = display_dirty_sinclair;
  display_write_if_dirty = display_write_if_dirty_sinclair;
  display_dirty_flashing = display_dirty_flashing_sinclair;

  memory_display_dirty = memory_display_dirty_sinclair;
}

int
rksspec_common_reset( void )
{
  /* 0x0000: ROM 0 */
  memory_map_16k( 0x0000, memory_map_rom, 0 );
  /* 0x4000: RAM 5, contended */
  memory_ram_set_16k_contention( 5, 1 );
  memory_map_16k( 0x4000, memory_map_ram, 5 );
  /* 0x8000: RAM 2, not contended */
  memory_ram_set_16k_contention( 0, 0 );
  memory_map_16k( 0x8000, memory_map_ram, 0 );
  /* 0xc000: RAM 0, not contended */
  memory_ram_set_16k_contention( 2, 0 );
  memory_map_16k( 0xc000, memory_map_ram, 2 );

  rom_idx=0;
  ram_idx=0;
  machine_current->ram.locked=0;  
  return 0;
}

static int rksspec_paging_memory_map( int rom, int page )
{
  /* ROM as specified */
  memory_map_16k( 0x0000, memory_map_rom, rom );
  /* RAM 5 */
  memory_map_16k( 0x4000, memory_map_ram, 5 );
  /* upper 32k RAM  */
  memory_map_16k( 0x8000, memory_map_ram, page);
  memory_map_16k( 0xC000, memory_map_ram, page+2);  

  return 0;
}


int rksspec_memory_map( void )
{
  //memory_map_16k( 0x0000, memory_map_rom, 0 ); 
  rksspec_paging_memory_map(rom_idx,ram_idx);

  memory_romcs_map();  
  
  return 0;
}


libspectrum_byte rksspec_configport_read( libspectrum_word port, libspectrum_byte *attached )
{  
  *attached=0xff;
  //how to emulate pullups on data bus - the default read on port 0xfe should be 0xff
  if (!machine_current->ram.locked){
    dbg("READ from CONFIG PORT=%d, val=%d", port & 0xff,CURR_0xFE_VAL);
    if ((port & 0xfe) == 0x76) {
      ram_idx=port & 1;
      rksspec_paging_memory_map(rom_idx,ram_idx);    
    }
    else if ((port & 0xfc) == 0xE0) 
    {
      rom_idx=port & 3;  
      rksspec_paging_memory_map(rom_idx,ram_idx);    
    }  
  }
  return 0xff;
}


libspectrum_byte rksspec_memoryport_read( libspectrum_word port, libspectrum_byte *attached )
{
  *attached=0xff;
  if (!machine_current->ram.locked){  
    dbg("READ from MEM PORT=%d, val=%d", port & 0xff,CURR_0xFE_VAL);
    rom_idx=3;
    rksspec_paging_memory_map(rom_idx,ram_idx);
    machine_current->ram.locked=1;
  }
  return 0xff;
}


