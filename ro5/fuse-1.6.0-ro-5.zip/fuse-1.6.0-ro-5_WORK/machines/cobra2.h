/* cobra1.h: CoBra 2 Turbo Spectrum (https://cobrasov.org) specific machine profile
   Copyright (c) 2023 Stefan V. Pantazi

   Copyright (c) 1999-2004 Philip Kendall

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

   Author contact information:

   Stefan V. Pantazi (svpantazi@gmail.com)
   Apr-Aug, 2023

*/

#ifndef FUSE_COBRA2_H
#define FUSE_COBRA2_H

#include <libspectrum.h>

#include "machine.h"

int cobra2_port_from_ula( libspectrum_word port );

int cobra2_init( fuse_machine_info *machine );
int cobra2_memory_map( void );

int cobra2_common_reset( void );

libspectrum_byte cobra2_configport_read( libspectrum_word port, libspectrum_byte *attached );
libspectrum_byte cobra2_memoryport_read( libspectrum_word port, libspectrum_byte *attached );
void cobra2_memoryport_write( libspectrum_word port, libspectrum_byte b );

#endif			/* #ifndef FUSE_COBRA2_H */
